/**
 * BungeeCord and Waterfall entry points: {@link me.tamkungz.signals.bungee.BungeeSignals} and the
 * {@link me.tamkungz.signals.bungee.SignalsBungeePlugin} that shares one bridge between plugins.
 */
package me.tamkungz.signals.bungee;
