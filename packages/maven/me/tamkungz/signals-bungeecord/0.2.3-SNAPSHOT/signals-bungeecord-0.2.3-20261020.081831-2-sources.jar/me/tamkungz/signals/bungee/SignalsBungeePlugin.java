package me.tamkungz.signals.bungee;

import me.tamkungz.signals.SignalBus;
import me.tamkungz.signals.connection.Connection;
import me.tamkungz.signals.connection.ConnectionGroup;
import net.md_5.bungee.api.plugin.Plugin;

/**
 * BungeeCord and Waterfall plugin entrypoint for proxies that want to load SignalsLib as a shared library.
 * <p>
 * Other plugins add {@code depends: [SignalsLib]} to their {@code bungee.yml} and use
 * {@link BungeeSignals#shared()}.
 */
public final class SignalsBungeePlugin extends Plugin {
    private static volatile SignalsBungeePlugin instance;

    private BungeeSignals signals;
    private ConnectionGroup connections;

    @Override
    public void onLoad() {
        connections = ConnectionGroup.create();
        signals = BungeeSignals.create(this);
        instance = this;
    }

    @Override
    public void onDisable() {
        if (connections != null) {
            connections.disconnect();
        }
        if (signals != null) {
            signals.bus().clear();
        }
        instance = null;
    }

    /**
     * Returns the loaded SignalsLib plugin.
     *
     * @return the plugin instance
     * @throws IllegalStateException if SignalsLib is not loaded
     */
    public static SignalsBungeePlugin getInstance() {
        SignalsBungeePlugin plugin = instance;
        if (plugin == null) {
            throw new IllegalStateException("SignalsLib is not loaded; add it to the proxy's plugins folder "
                    + "and depend on it in bungee.yml");
        }
        return plugin;
    }

    /**
     * Returns the bridge shared by every plugin.
     *
     * @return the shared bridge
     */
    public BungeeSignals signals() {
        return signals;
    }

    /**
     * Returns the signal bus shared by every plugin.
     *
     * @return the shared bus
     */
    public SignalBus bus() {
        return signals.bus();
    }

    /**
     * Returns the group that is disconnected when SignalsLib disables.
     *
     * @return the plugin's connection group
     */
    public ConnectionGroup connections() {
        return connections;
    }

    /**
     * Tracks a connection so it is disconnected when SignalsLib disables.
     *
     * @param connection connection to track
     * @param <T> connection type
     * @return the same connection
     */
    public <T extends Connection> T track(T connection) {
        return connections.add(connection);
    }
}
