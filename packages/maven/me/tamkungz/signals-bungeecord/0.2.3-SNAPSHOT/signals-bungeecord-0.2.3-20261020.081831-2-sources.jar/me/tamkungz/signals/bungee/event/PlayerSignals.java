package me.tamkungz.signals.bungee.event;

import me.tamkungz.signals.Signal;
import net.md_5.bungee.api.event.ChatEvent;
import net.md_5.bungee.api.event.LoginEvent;
import net.md_5.bungee.api.event.PlayerDisconnectEvent;
import net.md_5.bungee.api.event.PlayerHandshakeEvent;
import net.md_5.bungee.api.event.PostLoginEvent;
import net.md_5.bungee.api.event.PreLoginEvent;
import net.md_5.bungee.api.event.SettingsChangedEvent;
import net.md_5.bungee.api.event.TabCompleteEvent;

import java.util.Objects;

/**
 * Shortcuts for common BungeeCord player events, reached with {@code BungeeSignals#players()}.
 * <p>
 * Each method is the same as {@link EventSignalSource#on(Class)} for the named event class.
 * BungeeCord events are bridged at {@code NORMAL} priority.
 */
public final class PlayerSignals {
    private final EventSignalSource source;

    /**
     * Creates the shortcuts; prefer {@code BungeeSignals#players()}.
     *
     * @param source where the signals come from
     */
    public PlayerSignals(EventSignalSource source) {
        this.source = Objects.requireNonNull(source, "source");
    }

    /**
     * Listens to {@link PreLoginEvent}.
     *
     * @return the signal for that event
     */
    public Signal<PreLoginEvent> preLogin() {
        return source.on(PreLoginEvent.class);
    }

    /**
     * Listens to {@link LoginEvent}.
     *
     * @return the signal for that event
     */
    public Signal<LoginEvent> login() {
        return source.on(LoginEvent.class);
    }

    /**
     * Listens to {@link PostLoginEvent}.
     *
     * @return the signal for that event
     */
    public Signal<PostLoginEvent> join() {
        return source.on(PostLoginEvent.class);
    }

    /**
     * Listens to {@link PlayerDisconnectEvent}.
     *
     * @return the signal for that event
     */
    public Signal<PlayerDisconnectEvent> quit() {
        return source.on(PlayerDisconnectEvent.class);
    }

    /**
     * Listens to {@link PlayerHandshakeEvent}.
     *
     * @return the signal for that event
     */
    public Signal<PlayerHandshakeEvent> handshake() {
        return source.on(PlayerHandshakeEvent.class);
    }

    /**
     * Listens to {@link ChatEvent}.
     * <p>
     * BungeeCord fires this for commands too; check {@code event.isCommand()} to tell them apart.
     *
     * @return the signal for that event
     */
    public Signal<ChatEvent> chat() {
        return source.on(ChatEvent.class);
    }

    /**
     * Listens to {@link SettingsChangedEvent}.
     *
     * @return the signal for that event
     */
    public Signal<SettingsChangedEvent> settingsChanged() {
        return source.on(SettingsChangedEvent.class);
    }

    /**
     * Listens to {@link TabCompleteEvent}.
     *
     * @return the signal for that event
     */
    public Signal<TabCompleteEvent> tabComplete() {
        return source.on(TabCompleteEvent.class);
    }
}
