package me.tamkungz.signals.bungee.event;

import me.tamkungz.signals.Signal;
import net.md_5.bungee.api.plugin.Event;

/**
 * Supplies the {@link Signal} that carries a BungeeCord event type.
 * <p>
 * The per-domain accessors depend on this interface only, which keeps them free of {@code BungeeSignals} itself.
 */
public interface EventSignalSource {
    /**
     * Returns the signal for a bridged BungeeCord event type.
     *
     * @param eventType BungeeCord event type
     * @param <T> event type
     * @return the signal for that event type
     * @throws IllegalArgumentException if the event type is not bridged
     */
    <T extends Event> Signal<T> on(Class<T> eventType);
}
