package me.tamkungz.signals.bungee.event;

import me.tamkungz.signals.Signal;
import net.md_5.bungee.api.event.ServerConnectEvent;
import net.md_5.bungee.api.event.ServerConnectedEvent;
import net.md_5.bungee.api.event.ServerDisconnectEvent;
import net.md_5.bungee.api.event.ServerKickEvent;
import net.md_5.bungee.api.event.ServerSwitchEvent;

import java.util.Objects;

/**
 * Shortcuts for common BungeeCord backend server events, reached with {@code BungeeSignals#servers()}.
 * <p>
 * Each method is the same as {@link EventSignalSource#on(Class)} for the named event class.
 * BungeeCord events are bridged at {@code NORMAL} priority.
 */
public final class ServerSignals {
    private final EventSignalSource source;

    /**
     * Creates the shortcuts; prefer {@code BungeeSignals#servers()}.
     *
     * @param source where the signals come from
     */
    public ServerSignals(EventSignalSource source) {
        this.source = Objects.requireNonNull(source, "source");
    }

    /**
     * Listens to {@link ServerConnectEvent}.
     *
     * @return the signal for that event
     */
    public Signal<ServerConnectEvent> connect() {
        return source.on(ServerConnectEvent.class);
    }

    /**
     * Listens to {@link ServerConnectedEvent}.
     *
     * @return the signal for that event
     */
    public Signal<ServerConnectedEvent> connected() {
        return source.on(ServerConnectedEvent.class);
    }

    /**
     * Listens to {@link ServerSwitchEvent}.
     *
     * @return the signal for that event
     */
    public Signal<ServerSwitchEvent> switched() {
        return source.on(ServerSwitchEvent.class);
    }

    /**
     * Listens to {@link ServerKickEvent}.
     *
     * @return the signal for that event
     */
    public Signal<ServerKickEvent> kick() {
        return source.on(ServerKickEvent.class);
    }

    /**
     * Listens to {@link ServerDisconnectEvent}.
     *
     * @return the signal for that event
     */
    public Signal<ServerDisconnectEvent> disconnect() {
        return source.on(ServerDisconnectEvent.class);
    }
}
