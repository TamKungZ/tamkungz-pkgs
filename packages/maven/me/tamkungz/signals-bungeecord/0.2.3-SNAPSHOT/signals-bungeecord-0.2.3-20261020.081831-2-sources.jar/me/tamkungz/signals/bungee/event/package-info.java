/**
 * Per-domain shortcuts (players, servers, proxy) for the BungeeCord events that SignalsLib bridges.
 */
package me.tamkungz.signals.bungee.event;
