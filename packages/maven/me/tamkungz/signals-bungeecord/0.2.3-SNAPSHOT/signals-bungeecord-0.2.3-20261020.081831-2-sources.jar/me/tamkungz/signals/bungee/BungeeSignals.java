package me.tamkungz.signals.bungee;

import me.tamkungz.signals.Signal;
import me.tamkungz.signals.SignalBus;
import me.tamkungz.signals.bungee.event.EventSignalSource;
import me.tamkungz.signals.bungee.event.PlayerSignals;
import me.tamkungz.signals.bungee.event.ProxySignals;
import me.tamkungz.signals.bungee.event.ServerSignals;
import me.tamkungz.signals.bungee.internal.BungeeEventListener;
import net.md_5.bungee.api.plugin.Event;
import net.md_5.bungee.api.plugin.Plugin;

import java.util.Objects;
import java.util.Set;

/**
 * Small bridge from BungeeCord (and Waterfall) events to GEB-backed signals.
 * <p>
 * Common events are grouped by domain: {@link #players()}, {@link #servers()} and {@link #proxy()}. Any other
 * bridged event type is available through {@link #on(Class)}.
 * <p>
 * BungeeCord can only register handlers by reflecting over annotated methods, so the bridge covers a fixed list
 * of events (see {@link #bridgedEvents()}), all at {@code NORMAL} priority. For an event outside that list,
 * register a normal BungeeCord listener and fire into {@link #bus()} yourself.
 */
public final class BungeeSignals implements EventSignalSource {
    private final SignalBus bus;
    private final PlayerSignals players;
    private final ServerSignals servers;
    private final ProxySignals proxy;

    private BungeeSignals(Plugin plugin, SignalBus bus) {
        Objects.requireNonNull(plugin, "plugin");
        this.bus = Objects.requireNonNull(bus, "bus");
        this.players = new PlayerSignals(this);
        this.servers = new ServerSignals(this);
        this.proxy = new ProxySignals(this);
        plugin.getProxy().getPluginManager().registerListener(plugin, new BungeeEventListener(bus));
    }

    /**
     * Creates a bridge with its own signal bus.
     *
     * @param plugin plugin that owns the BungeeCord listener
     * @return a new bridge
     */
    public static BungeeSignals create(Plugin plugin) {
        return new BungeeSignals(plugin, SignalBus.create());
    }

    /**
     * Creates a bridge on an existing signal bus.
     *
     * @param plugin plugin that owns the BungeeCord listener
     * @param bus bus the signals live on
     * @return a new bridge
     */
    public static BungeeSignals create(Plugin plugin, SignalBus bus) {
        return new BungeeSignals(plugin, bus);
    }

    /**
     * Returns the bridge shared by every plugin through the installed SignalsLib plugin.
     *
     * @return the shared bridge
     */
    public static BungeeSignals shared() {
        return SignalsBungeePlugin.getInstance().signals();
    }

    /**
     * Returns the signal bus shared by every plugin through the installed SignalsLib plugin.
     *
     * @return the shared bus
     */
    public static SignalBus sharedBus() {
        return SignalsBungeePlugin.getInstance().bus();
    }

    /**
     * Returns the signal bus behind this bridge.
     *
     * @return the signal bus
     */
    public SignalBus bus() {
        return bus;
    }

    /**
     * Returns the BungeeCord event types this bridge forwards.
     *
     * @return an unmodifiable set of event types
     */
    public static Set<Class<? extends Event>> bridgedEvents() {
        return BungeeEventListener.bridgedTypes();
    }

    @Override
    public <T extends Event> Signal<T> on(Class<T> eventType) {
        Objects.requireNonNull(eventType, "eventType");
        if (!BungeeEventListener.isBridged(eventType)) {
            throw new IllegalArgumentException(eventType.getName() + " is not bridged by SignalsLib; "
                    + "register a BungeeCord listener and fire into bus() instead");
        }
        return bus.signal(eventType);
    }

    /**
     * Returns shortcuts for player events.
     *
     * @return player signals
     */
    public PlayerSignals players() {
        return players;
    }

    /**
     * Returns shortcuts for backend server events.
     *
     * @return server signals
     */
    public ServerSignals servers() {
        return servers;
    }

    /**
     * Returns shortcuts for proxy events.
     *
     * @return proxy signals
     */
    public ProxySignals proxy() {
        return proxy;
    }
}
