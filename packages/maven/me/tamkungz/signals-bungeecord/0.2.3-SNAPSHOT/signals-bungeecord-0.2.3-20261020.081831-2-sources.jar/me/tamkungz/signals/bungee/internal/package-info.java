/**
 * Implementation details of the BungeeCord bridge. Not part of the public API and may change without notice.
 */
package me.tamkungz.signals.bungee.internal;
