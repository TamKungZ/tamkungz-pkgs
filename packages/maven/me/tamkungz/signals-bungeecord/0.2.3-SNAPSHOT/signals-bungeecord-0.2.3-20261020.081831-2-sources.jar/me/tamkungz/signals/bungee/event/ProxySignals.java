package me.tamkungz.signals.bungee.event;

import me.tamkungz.signals.Signal;
import net.md_5.bungee.api.event.PluginMessageEvent;
import net.md_5.bungee.api.event.ProxyPingEvent;
import net.md_5.bungee.api.event.ProxyReloadEvent;

import java.util.Objects;

/**
 * Shortcuts for common BungeeCord proxy events, reached with {@code BungeeSignals#proxy()}.
 * <p>
 * Each method is the same as {@link EventSignalSource#on(Class)} for the named event class.
 * BungeeCord events are bridged at {@code NORMAL} priority.
 */
public final class ProxySignals {
    private final EventSignalSource source;

    /**
     * Creates the shortcuts; prefer {@code BungeeSignals#proxy()}.
     *
     * @param source where the signals come from
     */
    public ProxySignals(EventSignalSource source) {
        this.source = Objects.requireNonNull(source, "source");
    }

    /**
     * Listens to {@link ProxyPingEvent}.
     *
     * @return the signal for that event
     */
    public Signal<ProxyPingEvent> ping() {
        return source.on(ProxyPingEvent.class);
    }

    /**
     * Listens to {@link ProxyReloadEvent}.
     *
     * @return the signal for that event
     */
    public Signal<ProxyReloadEvent> reload() {
        return source.on(ProxyReloadEvent.class);
    }

    /**
     * Listens to {@link PluginMessageEvent}.
     *
     * @return the signal for that event
     */
    public Signal<PluginMessageEvent> pluginMessage() {
        return source.on(PluginMessageEvent.class);
    }
}
