package me.tamkungz.signals.bungee.internal;

import me.tamkungz.signals.SignalBus;
import net.md_5.bungee.api.event.ChatEvent;
import net.md_5.bungee.api.event.LoginEvent;
import net.md_5.bungee.api.event.PlayerDisconnectEvent;
import net.md_5.bungee.api.event.PlayerHandshakeEvent;
import net.md_5.bungee.api.event.PluginMessageEvent;
import net.md_5.bungee.api.event.PostLoginEvent;
import net.md_5.bungee.api.event.PreLoginEvent;
import net.md_5.bungee.api.event.ProxyPingEvent;
import net.md_5.bungee.api.event.ProxyReloadEvent;
import net.md_5.bungee.api.event.ServerConnectEvent;
import net.md_5.bungee.api.event.ServerConnectedEvent;
import net.md_5.bungee.api.event.ServerDisconnectEvent;
import net.md_5.bungee.api.event.ServerKickEvent;
import net.md_5.bungee.api.event.ServerSwitchEvent;
import net.md_5.bungee.api.event.SettingsChangedEvent;
import net.md_5.bungee.api.event.TabCompleteEvent;
import net.md_5.bungee.api.plugin.Event;
import net.md_5.bungee.api.plugin.Listener;
import net.md_5.bungee.event.EventHandler;

import java.util.Collections;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * The BungeeCord listener that forwards every bridged event to a {@link SignalBus}.
 * <p>
 * BungeeCord finds handlers by reflecting over {@link EventHandler} methods, so it cannot register a handler
 * for an event class chosen at runtime the way Bukkit can. Every bridged event therefore has a method here, all
 * at the default {@code NORMAL} priority.
 * <p>
 * Internal: use {@code BungeeSignals} instead.
 */
public final class BungeeEventListener implements Listener {
    private static final Set<Class<? extends Event>> BRIDGED = bridged();

    private final SignalBus bus;

    /**
     * Creates a listener that fires onto a bus.
     *
     * @param bus bus the events are forwarded to
     */
    public BungeeEventListener(SignalBus bus) {
        this.bus = Objects.requireNonNull(bus, "bus");
    }

    /**
     * Tells whether an event type is forwarded by this listener.
     *
     * @param eventType BungeeCord event type
     * @return {@code true} if a handler for it exists
     */
    public static boolean isBridged(Class<? extends Event> eventType) {
        return BRIDGED.contains(eventType);
    }

    /**
     * Returns every event type this listener forwards.
     *
     * @return an unmodifiable set of event types
     */
    public static Set<Class<? extends Event>> bridgedTypes() {
        return BRIDGED;
    }

    private static Set<Class<? extends Event>> bridged() {
        Set<Class<? extends Event>> types = new HashSet<>();
        types.add(PreLoginEvent.class);
        types.add(LoginEvent.class);
        types.add(PostLoginEvent.class);
        types.add(PlayerDisconnectEvent.class);
        types.add(PlayerHandshakeEvent.class);
        types.add(ChatEvent.class);
        types.add(SettingsChangedEvent.class);
        types.add(TabCompleteEvent.class);
        types.add(ServerConnectEvent.class);
        types.add(ServerConnectedEvent.class);
        types.add(ServerSwitchEvent.class);
        types.add(ServerKickEvent.class);
        types.add(ServerDisconnectEvent.class);
        types.add(ProxyPingEvent.class);
        types.add(ProxyReloadEvent.class);
        types.add(PluginMessageEvent.class);
        return Collections.unmodifiableSet(types);
    }

    // Skips building and dispatching an event nobody can receive. hasReceivers also counts the sub-buses of the bus;
    // listenerCount() alone would drop events whose only listeners live on a sub-bus.
    private <T extends Event> void forward(Class<T> eventType, T event) {
        if (bus.hasReceivers(eventType)) {
            bus.fire(eventType, event);
        }
    }

    @EventHandler
    public void onPreLogin(PreLoginEvent event) {
        forward(PreLoginEvent.class, event);
    }

    @EventHandler
    public void onLogin(LoginEvent event) {
        forward(LoginEvent.class, event);
    }

    @EventHandler
    public void onPostLogin(PostLoginEvent event) {
        forward(PostLoginEvent.class, event);
    }

    @EventHandler
    public void onPlayerDisconnect(PlayerDisconnectEvent event) {
        forward(PlayerDisconnectEvent.class, event);
    }

    @EventHandler
    public void onPlayerHandshake(PlayerHandshakeEvent event) {
        forward(PlayerHandshakeEvent.class, event);
    }

    @EventHandler
    public void onChat(ChatEvent event) {
        forward(ChatEvent.class, event);
    }

    @EventHandler
    public void onSettingsChanged(SettingsChangedEvent event) {
        forward(SettingsChangedEvent.class, event);
    }

    @EventHandler
    public void onTabComplete(TabCompleteEvent event) {
        forward(TabCompleteEvent.class, event);
    }

    @EventHandler
    public void onServerConnect(ServerConnectEvent event) {
        forward(ServerConnectEvent.class, event);
    }

    @EventHandler
    public void onServerConnected(ServerConnectedEvent event) {
        forward(ServerConnectedEvent.class, event);
    }

    @EventHandler
    public void onServerSwitch(ServerSwitchEvent event) {
        forward(ServerSwitchEvent.class, event);
    }

    @EventHandler
    public void onServerKick(ServerKickEvent event) {
        forward(ServerKickEvent.class, event);
    }

    @EventHandler
    public void onServerDisconnect(ServerDisconnectEvent event) {
        forward(ServerDisconnectEvent.class, event);
    }

    @EventHandler
    public void onProxyPing(ProxyPingEvent event) {
        forward(ProxyPingEvent.class, event);
    }

    @EventHandler
    public void onProxyReload(ProxyReloadEvent event) {
        forward(ProxyReloadEvent.class, event);
    }

    @EventHandler
    public void onPluginMessage(PluginMessageEvent event) {
        forward(PluginMessageEvent.class, event);
    }
}
