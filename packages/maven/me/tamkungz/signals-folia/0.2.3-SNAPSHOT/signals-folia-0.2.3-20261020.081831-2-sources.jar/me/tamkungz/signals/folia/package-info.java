/**
 * Folia entry points: {@link me.tamkungz.signals.folia.FoliaSignals} for connecting listeners on the right
 * thread, and {@link me.tamkungz.signals.folia.FoliaScheduler} for the region, entity, global and async schedulers.
 */
package me.tamkungz.signals.folia;
