package me.tamkungz.signals.folia;

import me.tamkungz.signals.Signal;
import me.tamkungz.signals.SignalBus;
import me.tamkungz.signals.bukkit.BukkitSignals;
import me.tamkungz.signals.bukkit.SignalsPlugin;
import me.tamkungz.signals.bukkit.event.BlockSignals;
import me.tamkungz.signals.bukkit.event.EntitySignals;
import me.tamkungz.signals.bukkit.event.EventSignalSource;
import me.tamkungz.signals.bukkit.event.InventorySignals;
import me.tamkungz.signals.bukkit.event.PlayerSignals;
import me.tamkungz.signals.connection.Connection;
import me.tamkungz.signals.connection.ConnectionGroup;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;
import org.bukkit.plugin.Plugin;

import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;

/**
 * {@link BukkitSignals} for Folia: the same signals, plus listeners that hop to the thread they need.
 * <p>
 * On Folia a Bukkit event is fired on the thread of the region that owns it, and a listener may only touch
 * blocks, chunks and entities of that region. When a listener has to work on something owned by another region
 * (the world around a location, another player, ...), connect it with {@link #connectRegion},
 * {@link #connectEntity}, {@link #connectGlobal} or {@link #connectAsync}. Those run the listener inline when
 * the current thread already is the right one and schedule it otherwise.
 * <p>
 * Signals and connections are thread-safe, so plain {@code connect} calls from any region thread are fine.
 * <p>
 * A listener that had to be scheduled runs after the event has already finished, so calls such as
 * {@code setCancelled} or {@code setMessage} on that event no longer change the outcome. Use a plain
 * {@code connect} on the signal when the listener has to decide the event.
 */
public final class FoliaSignals implements EventSignalSource {
    private final BukkitSignals bukkit;
    private final FoliaScheduler scheduler;

    private FoliaSignals(Plugin plugin, BukkitSignals bukkit) {
        this.bukkit = Objects.requireNonNull(bukkit, "bukkit");
        this.scheduler = new FoliaScheduler(Objects.requireNonNull(plugin, "plugin"));
    }

    /**
     * Creates a bridge with its own signal bus.
     *
     * @param plugin plugin that owns the Bukkit listeners and the scheduled tasks
     * @return a new bridge
     */
    public static FoliaSignals create(Plugin plugin) {
        return new FoliaSignals(plugin, BukkitSignals.create(plugin));
    }

    /**
     * Creates a bridge on an existing signal bus.
     *
     * @param plugin plugin that owns the Bukkit listeners and the scheduled tasks
     * @param bus bus the signals live on
     * @return a new bridge
     */
    public static FoliaSignals create(Plugin plugin, SignalBus bus) {
        return new FoliaSignals(plugin, BukkitSignals.create(plugin, bus));
    }

    /**
     * Returns a bridge over the one shared by every plugin through the installed SignalsLib plugin.
     * <p>
     * Events and listeners are shared with {@link BukkitSignals#shared()}; scheduled tasks belong to SignalsLib.
     *
     * @return a bridge over the shared signals
     */
    public static FoliaSignals shared() {
        SignalsPlugin plugin = SignalsPlugin.getInstance();
        return new FoliaSignals(plugin, plugin.signals());
    }

    /**
     * Returns the Bukkit bridge behind this one.
     *
     * @return the Bukkit bridge
     */
    public BukkitSignals bukkit() {
        return bukkit;
    }

    /**
     * Returns the signal bus behind this bridge.
     *
     * @return the signal bus
     */
    public SignalBus bus() {
        return bukkit.bus();
    }

    /**
     * Returns the scheduler wrapper of this bridge.
     *
     * @return the scheduler
     */
    public FoliaScheduler scheduler() {
        return scheduler;
    }

    @Override
    public <T extends Event> Signal<T> signal(Class<T> eventType, EventPriority priority, boolean ignoreCancelled) {
        return bukkit.signal(eventType, priority, ignoreCancelled);
    }

    /**
     * Returns shortcuts for player events.
     *
     * @return player signals
     */
    public PlayerSignals players() {
        return bukkit.players();
    }

    /**
     * Returns shortcuts for block events.
     *
     * @return block signals
     */
    public BlockSignals blocks() {
        return bukkit.blocks();
    }

    /**
     * Returns shortcuts for entity events.
     *
     * @return entity signals
     */
    public EntitySignals entities() {
        return bukkit.entities();
    }

    /**
     * Returns shortcuts for inventory events.
     *
     * @return inventory signals
     */
    public InventorySignals inventories() {
        return bukkit.inventories();
    }

    /**
     * Connects a listener that runs on the global region thread.
     *
     * @param signal signal to listen to
     * @param listener listener to call
     * @param <T> payload type
     * @return the connection for this listener
     */
    public <T> Connection connectGlobal(Signal<T> signal, Consumer<T> listener) {
        return connectVia(signal, listener, (value, task) -> {
            if (scheduler.isGlobalThread()) {
                task.run();
            } else {
                scheduler.global(task);
            }
        });
    }

    /**
     * Connects a listener that runs on the global region thread and tracks it in a group.
     *
     * @param group group that will disconnect the listener
     * @param signal signal to listen to
     * @param listener listener to call
     * @param <T> payload type
     * @return the connection for this listener
     */
    public <T> Connection connectGlobal(ConnectionGroup group, Signal<T> signal, Consumer<T> listener) {
        Objects.requireNonNull(group, "group");
        return group.add(connectGlobal(signal, listener));
    }

    /**
     * Connects a listener that always runs on an async thread, never on a region thread.
     *
     * @param signal signal to listen to
     * @param listener listener to call
     * @param <T> payload type
     * @return the connection for this listener
     */
    public <T> Connection connectAsync(Signal<T> signal, Consumer<T> listener) {
        return connectVia(signal, listener, (value, task) -> scheduler.async(task));
    }

    /**
     * Connects a listener that always runs on an async thread and tracks it in a group.
     *
     * @param group group that will disconnect the listener
     * @param signal signal to listen to
     * @param listener listener to call
     * @param <T> payload type
     * @return the connection for this listener
     */
    public <T> Connection connectAsync(ConnectionGroup group, Signal<T> signal, Consumer<T> listener) {
        Objects.requireNonNull(group, "group");
        return group.add(connectAsync(signal, listener));
    }

    /**
     * Connects a listener that runs on the thread of the region that owns a location taken from the payload.
     *
     * @param signal signal to listen to
     * @param locator picks the location from the payload, must not return {@code null}
     * @param listener listener to call
     * @param <T> payload type
     * @return the connection for this listener
     */
    public <T> Connection connectRegion(
            Signal<T> signal,
            Function<? super T, ? extends Location> locator,
            Consumer<T> listener
    ) {
        Objects.requireNonNull(locator, "locator");
        return connectVia(signal, listener, (value, task) -> {
            Location location = Objects.requireNonNull(locator.apply(value), "locator returned null");
            if (scheduler.ownsRegion(location)) {
                task.run();
            } else {
                scheduler.region(location, task);
            }
        });
    }

    /**
     * Connects a listener that runs on the region thread of a location taken from the payload and tracks it
     * in a group.
     *
     * @param group group that will disconnect the listener
     * @param signal signal to listen to
     * @param locator picks the location from the payload, must not return {@code null}
     * @param listener listener to call
     * @param <T> payload type
     * @return the connection for this listener
     */
    public <T> Connection connectRegion(
            ConnectionGroup group,
            Signal<T> signal,
            Function<? super T, ? extends Location> locator,
            Consumer<T> listener
    ) {
        Objects.requireNonNull(group, "group");
        return group.add(connectRegion(signal, locator, listener));
    }

    /**
     * Connects a listener that runs on the thread of the region that owns an entity taken from the payload.
     * <p>
     * If the entity is removed before the listener gets to run, that call is dropped.
     *
     * @param signal signal to listen to
     * @param locator picks the entity from the payload, must not return {@code null}
     * @param listener listener to call
     * @param <T> payload type
     * @return the connection for this listener
     */
    public <T> Connection connectEntity(
            Signal<T> signal,
            Function<? super T, ? extends Entity> locator,
            Consumer<T> listener
    ) {
        Objects.requireNonNull(locator, "locator");
        return connectVia(signal, listener, (value, task) -> {
            Entity entity = Objects.requireNonNull(locator.apply(value), "locator returned null");
            if (scheduler.ownsEntity(entity)) {
                task.run();
            } else {
                scheduler.entity(entity, task, null);
            }
        });
    }

    /**
     * Connects a listener that runs on the region thread of an entity taken from the payload and tracks it
     * in a group.
     *
     * @param group group that will disconnect the listener
     * @param signal signal to listen to
     * @param locator picks the entity from the payload, must not return {@code null}
     * @param listener listener to call
     * @param <T> payload type
     * @return the connection for this listener
     */
    public <T> Connection connectEntity(
            ConnectionGroup group,
            Signal<T> signal,
            Function<? super T, ? extends Entity> locator,
            Consumer<T> listener
    ) {
        Objects.requireNonNull(group, "group");
        return group.add(connectEntity(signal, locator, listener));
    }

    /**
     * Connects {@code listener}, handing every value to {@code dispatcher} first. The dispatcher decides on
     * which thread the task it receives runs. A task that was scheduled before the connection was
     * disconnected is skipped.
     */
    private static <T> Connection connectVia(
            Signal<T> signal,
            Consumer<T> listener,
            BiConsumer<T, Runnable> dispatcher
    ) {
        Objects.requireNonNull(signal, "signal");
        Objects.requireNonNull(listener, "listener");
        AtomicReference<Connection> self = new AtomicReference<>();
        Connection connection = signal.connect(value -> dispatcher.accept(value, () -> {
            Connection current = self.get();
            if (current == null || current.isConnected()) {
                listener.accept(value);
            }
        }));
        self.set(connection);
        return connection;
    }
}
