package me.tamkungz.signals.folia;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Server;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;
import java.util.Objects;

/**
 * Small wrapper over the Folia schedulers for one plugin.
 * <p>
 * On Folia every region ticks on its own thread, so code that touches a block, chunk or entity must run on the
 * thread that owns it. The methods here pick the matching scheduler; {@link #ownsRegion(Location)},
 * {@link #ownsEntity(Entity)} and {@link #isGlobalThread()} tell whether the current thread already is that
 * thread. Outside Folia, Paper runs the same schedulers on the main thread.
 */
public final class FoliaScheduler {
    // Server#isGlobalTickThread exists only in the Folia API, not in Paper's, so it is looked up at runtime.
    private static final Method GLOBAL_TICK_THREAD = findGlobalTickThread();
    // Looked up once: the answer cannot change while the server runs, and a failed Class.forName is expensive
    // on the paths that call isFolia() for every event.
    private static final boolean FOLIA = detectFolia();

    private final Plugin plugin;

    /**
     * Creates a scheduler for a plugin.
     *
     * @param plugin plugin that owns the scheduled tasks
     */
    public FoliaScheduler(Plugin plugin) {
        this.plugin = Objects.requireNonNull(plugin, "plugin");
    }

    /**
     * Tells whether the server is Folia.
     *
     * @return {@code true} when regionised multithreading is active
     */
    public static boolean isFolia() {
        return FOLIA;
    }

    private static boolean detectFolia() {
        try {
            Class.forName("io.papermc.paper.threadedregions.RegionizedServer");
            return true;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    private static Method findGlobalTickThread() {
        try {
            return Server.class.getMethod("isGlobalTickThread");
        } catch (NoSuchMethodException e) {
            return null;
        }
    }

    /**
     * Returns the plugin that owns the scheduled tasks.
     *
     * @return the owning plugin
     */
    public Plugin plugin() {
        return plugin;
    }

    /**
     * Tells whether the current thread is the global region thread (the main thread outside Folia).
     * Returns {@code false} on a Folia build that does not expose the check, so callers schedule instead.
     *
     * @return {@code true} on the global tick thread
     */
    public boolean isGlobalThread() {
        if (GLOBAL_TICK_THREAD == null) {
            // Without the Folia check, only claim the global thread outside Folia; on Folia always schedule.
            return !isFolia() && Bukkit.isPrimaryThread();
        }
        try {
            return (Boolean) GLOBAL_TICK_THREAD.invoke(Bukkit.getServer());
        } catch (ReflectiveOperationException e) {
            return false;
        }
    }

    /**
     * Tells whether the current thread owns the region around a location.
     *
     * @param location location to check
     * @return {@code true} if the current region owns it
     */
    public boolean ownsRegion(Location location) {
        return Bukkit.isOwnedByCurrentRegion(Objects.requireNonNull(location, "location"));
    }

    /**
     * Tells whether the current thread owns an entity.
     *
     * @param entity entity to check
     * @return {@code true} if the current region owns it
     */
    public boolean ownsEntity(Entity entity) {
        return Bukkit.isOwnedByCurrentRegion(Objects.requireNonNull(entity, "entity"));
    }

    /**
     * Runs a task on the next tick of the global region.
     *
     * @param task task to run
     */
    public void global(Runnable task) {
        Objects.requireNonNull(task, "task");
        Bukkit.getGlobalRegionScheduler().execute(plugin, task);
    }

    /**
     * Runs a task on the next tick of the region that owns a location.
     *
     * @param location location whose region runs the task
     * @param task task to run
     */
    public void region(Location location, Runnable task) {
        Objects.requireNonNull(location, "location");
        Objects.requireNonNull(task, "task");
        Bukkit.getRegionScheduler().execute(plugin, location, task);
    }

    /**
     * Runs a task on the next tick of the region that owns a chunk.
     *
     * @param world world of the chunk
     * @param chunkX chunk X coordinate
     * @param chunkZ chunk Z coordinate
     * @param task task to run
     */
    public void region(World world, int chunkX, int chunkZ, Runnable task) {
        Objects.requireNonNull(world, "world");
        Objects.requireNonNull(task, "task");
        Bukkit.getRegionScheduler().execute(plugin, world, chunkX, chunkZ, task);
    }

    /**
     * Runs a task on the next tick of the region that owns an entity, following the entity if it moves.
     *
     * @param entity entity whose region runs the task
     * @param task task to run
     * @param retired called instead of {@code task} if the entity was removed first, may be {@code null}
     * @return {@code false} if the entity was already removed and the task was not scheduled
     */
    public boolean entity(Entity entity, Runnable task, Runnable retired) {
        Objects.requireNonNull(entity, "entity");
        Objects.requireNonNull(task, "task");
        return entity.getScheduler().run(plugin, scheduled -> task.run(), retired) != null;
    }

    /**
     * Runs a task right away on a thread that is not tied to any region.
     *
     * @param task task to run
     */
    public void async(Runnable task) {
        Objects.requireNonNull(task, "task");
        Bukkit.getAsyncScheduler().runNow(plugin, scheduled -> task.run());
    }
}
