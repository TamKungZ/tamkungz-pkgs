package me.tamkungz.signals.connection;

/**
 * Handle for a registered listener or bus registration.
 * <p>
 * {@link #disconnect()} is idempotent: calling it more than once is safe.
 */
public interface Connection {
    /**
     * Combines several connections so they can be disconnected together.
     *
     * @param connections connections to combine
     * @return a group tracking every given connection
     */
    static Connection all(Connection... connections) {
        return ConnectionGroup.of(connections);
    }

    /**
     * Returns a connection that is already disconnected.
     *
     * @return a no-op, permanently disconnected connection
     */
    static Connection disconnected() {
        return new Connection() {
            @Override
            public void disconnect() {
            }

            @Override
            public boolean isConnected() {
                return false;
            }
        };
    }

    /**
     * Stops this connection from receiving further values.
     */
    void disconnect();

    /**
     * Tells whether this connection is still active.
     *
     * @return {@code true} until {@link #disconnect()} has been called
     */
    boolean isConnected();

    /**
     * Alias of {@link #disconnect()}.
     */
    default void close() {
        disconnect();
    }
}
