/**
 * Direct GEB access for custom events, {@code @Listen} listeners and sub-buses.
 */
package me.tamkungz.signals.geb;
