/**
 * Implementation details of the signal bus. Not part of the public API and may change without notice.
 */
package me.tamkungz.signals.internal;
