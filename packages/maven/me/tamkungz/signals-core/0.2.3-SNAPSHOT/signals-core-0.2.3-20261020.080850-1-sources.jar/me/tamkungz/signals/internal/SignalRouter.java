package me.tamkungz.signals.internal;

import foo.zaaarf.geb.api.IListener;
import me.tamkungz.signals.SignalKey;
import me.tamkungz.signals.connection.Connection;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;

/**
 * Routes {@link SignalEnvelope}s arriving from GEB to the listeners registered for their key.
 * <p>
 * Internal: use {@link me.tamkungz.signals.SignalBus} instead. The class is public only because the bus lives
 * in another package.
 */
public final class SignalRouter implements IListener {
    private final ConcurrentMap<SignalKey<?>, CopyOnWriteArrayList<Subscription<?>>> listeners = new ConcurrentHashMap<>();

    /**
     * Registers a listener for a key.
     *
     * @param key key to listen on
     * @param listener listener to call
     * @param <T> payload type
     * @return the connection for this listener
     */
    public <T> Connection connect(SignalKey<T> key, Consumer<T> listener) {
        Objects.requireNonNull(key, "key");
        Objects.requireNonNull(listener, "listener");

        Subscription<T> subscription = new Subscription<>(key, listener, this::remove);
        listeners.compute(key, (ignored, existing) -> {
            CopyOnWriteArrayList<Subscription<?>> list = existing == null ? new CopyOnWriteArrayList<>() : existing;
            list.add(subscription);
            return list;
        });
        return subscription;
    }

    /**
     * Registers a listener that is disconnected after its first value.
     *
     * @param key key to listen on
     * @param listener listener to call at most once
     * @param <T> payload type
     * @return the connection for this listener
     */
    public <T> Connection once(SignalKey<T> key, Consumer<T> listener) {
        Objects.requireNonNull(listener, "listener");
        AtomicBoolean fired = new AtomicBoolean();
        AtomicReference<Connection> self = new AtomicReference<>();
        Connection connection = connect(key, value -> {
            if (!fired.compareAndSet(false, true)) {
                return;
            }
            Connection current = self.get();
            if (current != null) {
                current.disconnect();
            }
            listener.accept(value);
        });
        self.set(connection);
        if (fired.get()) {
            connection.disconnect();
        }
        return connection;
    }

    /**
     * Counts the listeners connected to a key.
     *
     * @param key key to inspect
     * @return number of connected listeners
     */
    public int listenerCount(SignalKey<?> key) {
        List<Subscription<?>> subscriptions = listeners.get(key);
        return subscriptions == null ? 0 : subscriptions.size();
    }

    /**
     * Disconnects every listener of a key.
     *
     * @param key key to clear
     */
    public void clear(SignalKey<?> key) {
        List<Subscription<?>> subscriptions = listeners.remove(key);
        if (subscriptions == null) {
            return;
        }

        for (Subscription<?> subscription : subscriptions) {
            subscription.disconnect();
        }
    }

    /**
     * Disconnects every listener of every key.
     */
    public void clear() {
        for (SignalKey<?> key : listeners.keySet()) {
            clear(key);
        }
    }

    /**
     * Delivers an envelope to the listeners of its key; {@link SignalEnvelopeDispatcher} calls it for every
     * envelope that reaches the bus.
     * <p>
     * A throwing listener does not stop the others; the first failure is rethrown afterwards with
     * the rest attached as suppressed exceptions.
     *
     * @param event envelope to deliver
     */
    public void onSignal(SignalEnvelope<?> event) {
        List<Subscription<?>> subscriptions = listeners.get(event.key());
        if (subscriptions == null) {
            return;
        }

        RuntimeException failure = null;
        for (Subscription<?> subscription : subscriptions) {
            try {
                subscription.accept(event.value());
            } catch (RuntimeException e) {
                if (failure == null) {
                    failure = e;
                } else {
                    failure.addSuppressed(e);
                }
            }
        }
        if (failure != null) {
            throw failure;
        }
    }

    private void remove(Subscription<?> subscription) {
        listeners.computeIfPresent(subscription.key(), (ignored, subscriptions) -> {
            subscriptions.remove(subscription);
            return subscriptions.isEmpty() ? null : subscriptions;
        });
    }
}
