/**
 * Core API: {@link me.tamkungz.signals.SignalBus}, {@link me.tamkungz.signals.Signal} and
 * {@link me.tamkungz.signals.SignalKey}.
 */
package me.tamkungz.signals;
