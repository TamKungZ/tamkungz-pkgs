package me.tamkungz.signals;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Identifies one signal channel: a payload type plus a name.
 * <p>
 * Keys with the same type and name address the same channel; derived keys created by
 * {@link Signal#filter} and {@link Signal#map} are always unique.
 * <p>
 * Primitive payload types are boxed, so {@code int.class} and {@code Integer.class} address the same channel
 * and {@link #eventType()} reports {@code Integer.class} for both.
 *
 * @param <T> payload type
 */
public final class SignalKey<T> {
    private static final AtomicLong NEXT_ID = new AtomicLong();
    private static final Map<Class<?>, Class<?>> BOXES = boxes();

    private final Class<T> eventType;
    private final String name;
    private final long uniqueId;

    private SignalKey(Class<T> eventType, String name, long uniqueId) {
        this.eventType = box(Objects.requireNonNull(eventType, "eventType"));
        this.name = Objects.requireNonNull(name, "name");
        this.uniqueId = uniqueId;
    }

    private static Map<Class<?>, Class<?>> boxes() {
        Map<Class<?>, Class<?>> boxes = new HashMap<>();
        boxes.put(boolean.class, Boolean.class);
        boxes.put(byte.class, Byte.class);
        boxes.put(char.class, Character.class);
        boxes.put(short.class, Short.class);
        boxes.put(int.class, Integer.class);
        boxes.put(long.class, Long.class);
        boxes.put(float.class, Float.class);
        boxes.put(double.class, Double.class);
        boxes.put(void.class, Void.class);
        return boxes;
    }

    // Class#cast rejects every value for a primitive class, so a signal on int.class could never be fired.
    @SuppressWarnings("unchecked")
    private static <T> Class<T> box(Class<T> type) {
        Class<?> boxed = BOXES.get(type);
        return boxed == null ? type : (Class<T>) boxed;
    }

    /**
     * Returns the default key of a payload type, the same as {@code named(eventType, "default")}.
     *
     * @param eventType payload type
     * @param <T> payload type
     * @return the default key for the type
     */
    public static <T> SignalKey<T> of(Class<T> eventType) {
        return named(eventType, "default");
    }

    /**
     * Returns the key of a named channel for a payload type.
     *
     * @param eventType payload type
     * @param name channel name
     * @param <T> payload type
     * @return the key for that type and name
     */
    public static <T> SignalKey<T> named(Class<T> eventType, String name) {
        return new SignalKey<>(eventType, name, 0L);
    }

    static <T> SignalKey<T> unique(Class<T> eventType) {
        long id = NEXT_ID.incrementAndGet();
        return new SignalKey<>(eventType, "derived-" + id, id);
    }

    /**
     * Returns the payload type, with primitives boxed.
     *
     * @return payload class
     */
    public Class<T> eventType() {
        return eventType;
    }

    /**
     * Returns the channel name.
     *
     * @return channel name
     */
    public String name() {
        return name;
    }

    /**
     * Casts a value to this key's payload type.
     *
     * @param value value to cast, may be {@code null}
     * @return the value as {@code T}
     * @throws ClassCastException if the value is not an instance of the payload type
     */
    public T cast(Object value) {
        return eventType.cast(value);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof SignalKey)) {
            return false;
        }
        SignalKey<?> key = (SignalKey<?>) other;
        return uniqueId == key.uniqueId && eventType.equals(key.eventType) && name.equals(key.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(eventType, name, uniqueId);
    }

    @Override
    public String toString() {
        return eventType.getName() + "#" + name;
    }
}
