/**
 * Connection handles and groups used to disconnect listeners.
 */
package me.tamkungz.signals.connection;
