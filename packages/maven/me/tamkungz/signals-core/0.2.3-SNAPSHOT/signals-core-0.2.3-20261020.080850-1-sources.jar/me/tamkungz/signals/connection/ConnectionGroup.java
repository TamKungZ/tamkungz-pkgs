package me.tamkungz.signals.connection;

import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Tracks many connections and disconnects them all at once, for example when a plugin disables.
 * <p>
 * Connections added after the group was disconnected are disconnected immediately.
 */
public final class ConnectionGroup implements Connection {
    private static final int MIN_PRUNE_THRESHOLD = 32;

    private final CopyOnWriteArrayList<Connection> connections = new CopyOnWriteArrayList<>();
    private final AtomicBoolean connected = new AtomicBoolean(true);
    private volatile int pruneThreshold = MIN_PRUNE_THRESHOLD;

    /**
     * Creates an empty group.
     *
     * @return a new, connected group
     */
    public static ConnectionGroup create() {
        return new ConnectionGroup();
    }

    /**
     * Creates a group that tracks the given connections.
     *
     * @param connections connections to track, none of them may be {@code null}
     * @return a new, connected group
     */
    public static ConnectionGroup of(Connection... connections) {
        Objects.requireNonNull(connections, "connections");
        ConnectionGroup group = create();
        for (Connection connection : connections) {
            group.add(connection);
        }
        return group;
    }

    /**
     * Tracks a connection. If the group is already disconnected, the connection is disconnected right away.
     *
     * @param connection connection to track
     * @param <T> connection type
     * @return the same connection
     */
    public <T extends Connection> T add(T connection) {
        Objects.requireNonNull(connection, "connection");
        if (isConnected()) {
            pruneIfLarge();
            connections.add(connection);
            if (!isConnected()) {
                connections.remove(connection);
                connection.disconnect();
            }
        } else {
            connection.disconnect();
        }
        return connection;
    }

    /**
     * Returns how many connections the group currently tracks.
     * <p>
     * Connections that were disconnected on their own are dropped as the group grows, so this can include a
     * few that are no longer connected.
     *
     * @return number of tracked connections
     */
    public int size() {
        return connections.size();
    }

    private void pruneIfLarge() {
        if (connections.size() < pruneThreshold) {
            return;
        }
        connections.removeIf(entry -> !entry.isConnected());
        pruneThreshold = Math.max(MIN_PRUNE_THRESHOLD, connections.size() * 2);
    }

    /**
     * Disconnects every tracked connection and stops accepting new ones.
     * <p>
     * A connection that fails to disconnect does not stop the rest; the first failure is rethrown afterwards
     * with the others attached as suppressed exceptions.
     */
    @Override
    public void disconnect() {
        if (!connected.compareAndSet(true, false)) {
            return;
        }

        RuntimeException failure = null;
        for (Connection connection : connections) {
            try {
                connection.disconnect();
            } catch (RuntimeException e) {
                if (failure == null) {
                    failure = e;
                } else {
                    failure.addSuppressed(e);
                }
            }
        }
        connections.clear();
        if (failure != null) {
            throw failure;
        }
    }

    @Override
    public boolean isConnected() {
        return connected.get();
    }
}
