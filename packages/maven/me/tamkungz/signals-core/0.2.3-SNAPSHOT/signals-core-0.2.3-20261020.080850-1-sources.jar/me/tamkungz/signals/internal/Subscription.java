package me.tamkungz.signals.internal;

import me.tamkungz.signals.SignalKey;
import me.tamkungz.signals.connection.Connection;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

/**
 * One listener registered on one {@link SignalKey}; the {@link Connection} handed back to callers.
 */
final class Subscription<T> implements Connection {
    private final SignalKey<T> key;
    private final Consumer<T> listener;
    private final Consumer<Subscription<?>> onDisconnect;
    private final AtomicBoolean connected = new AtomicBoolean(true);

    Subscription(SignalKey<T> key, Consumer<T> listener, Consumer<Subscription<?>> onDisconnect) {
        this.key = key;
        this.listener = listener;
        this.onDisconnect = onDisconnect;
    }

    SignalKey<T> key() {
        return key;
    }

    @Override
    public void disconnect() {
        if (connected.compareAndSet(true, false)) {
            onDisconnect.accept(this);
        }
    }

    @Override
    public boolean isConnected() {
        return connected.get();
    }

    void accept(Object value) {
        if (isConnected()) {
            listener.accept(key.cast(value));
        }
    }
}
