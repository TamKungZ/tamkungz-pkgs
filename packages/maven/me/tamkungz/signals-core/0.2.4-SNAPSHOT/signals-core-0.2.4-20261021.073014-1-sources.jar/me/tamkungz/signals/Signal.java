package me.tamkungz.signals;

import me.tamkungz.signals.connection.Connection;
import me.tamkungz.signals.connection.ConnectionGroup;

import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * Lightweight signal facade for a single payload type.
 * <p>
 * A signal is a view of one channel on a {@link SignalBus}: every {@code Signal} created for the same
 * {@link SignalKey} shares the same listeners.
 *
 * @param <T> event payload type
 */
public final class Signal<T> {
    private final SignalBus bus;
    private final SignalKey<T> key;
    private volatile Connection upstream = Connection.disconnected();

    Signal(SignalBus bus, SignalKey<T> key) {
        this.bus = Objects.requireNonNull(bus, "bus");
        this.key = Objects.requireNonNull(key, "key");
    }

    /**
     * Returns the bus this signal lives on.
     *
     * @return the signal bus
     */
    public SignalBus bus() {
        return bus;
    }

    /**
     * Returns the key of this signal's channel.
     *
     * @return the signal key
     */
    public SignalKey<T> key() {
        return key;
    }

    /**
     * Returns the payload type of this signal.
     *
     * @return payload class
     */
    public Class<T> eventType() {
        return key.eventType();
    }

    /**
     * Connects a listener.
     *
     * @param listener listener to call for every value
     * @return the connection for this listener
     */
    public Connection connect(Consumer<T> listener) {
        return bus.connect(key, listener);
    }

    /**
     * Connects a listener and tracks it in a group.
     *
     * @param group group that will disconnect the listener
     * @param listener listener to call for every value
     * @return the connection for this listener
     */
    public Connection connect(ConnectionGroup group, Consumer<T> listener) {
        Objects.requireNonNull(group, "group");
        return group.add(connect(listener));
    }

    /**
     * Connects a listener that only receives the values a predicate accepts.
     *
     * @param predicate decides which values reach the listener
     * @param listener listener to call for accepted values
     * @return the connection for this listener
     */
    public Connection connectIf(Predicate<T> predicate, Consumer<T> listener) {
        Objects.requireNonNull(predicate, "predicate");
        Objects.requireNonNull(listener, "listener");
        return connect(value -> {
            if (predicate.test(value)) {
                listener.accept(value);
            }
        });
    }

    /**
     * Connects a filtered listener and tracks it in a group.
     *
     * @param group group that will disconnect the listener
     * @param predicate decides which values reach the listener
     * @param listener listener to call for accepted values
     * @return the connection for this listener
     */
    public Connection connectIf(ConnectionGroup group, Predicate<T> predicate, Consumer<T> listener) {
        Objects.requireNonNull(group, "group");
        return group.add(connectIf(predicate, listener));
    }

    /**
     * Connects a listener that runs on an executor instead of on the thread that fires the signal.
     * <p>
     * Every value is handed to the executor as a task, so a listener can hop to the thread it needs, for example
     * the server's main thread. Values are delivered in the order the executor runs the tasks. A task that is still
     * queued when the connection is disconnected is skipped.
     * <p>
     * Whatever the listener does happens after {@link #fire} has returned, so it cannot change an event the firing
     * code is still waiting on (cancel it, change its message, ...). If the executor throws while accepting a
     * task, the exception is treated like one thrown by any other listener. Exceptions from the listener itself
     * are handled by the executor, not by the bus.
     *
     * @param executor executor that runs the listener
     * @param listener listener to call for every value
     * @return the connection for this listener
     */
    public Connection connectOn(Executor executor, Consumer<T> listener) {
        Objects.requireNonNull(executor, "executor");
        Objects.requireNonNull(listener, "listener");
        AtomicReference<Connection> self = new AtomicReference<>();
        Connection connection = connect(value -> executor.execute(() -> {
            Connection current = self.get();
            // A value can arrive before connect() has returned; self is still empty then, and it must be delivered.
            if (current == null || current.isConnected()) {
                listener.accept(value);
            }
        }));
        self.set(connection);
        return connection;
    }

    /**
     * Connects a listener that runs on an executor and tracks it in a group.
     *
     * @param group group that will disconnect the listener
     * @param executor executor that runs the listener
     * @param listener listener to call for every value
     * @return the connection for this listener
     * @see #connectOn(Executor, Consumer)
     */
    public Connection connectOn(ConnectionGroup group, Executor executor, Consumer<T> listener) {
        Objects.requireNonNull(group, "group");
        return group.add(connectOn(executor, listener));
    }

    /**
     * Connects a listener that is disconnected after its first value.
     *
     * @param listener listener to call at most once
     * @return the connection for this listener
     */
    public Connection once(Consumer<T> listener) {
        return bus.once(key, listener);
    }

    /**
     * Connects a one-shot listener and tracks it in a group.
     *
     * @param group group that will disconnect the listener
     * @param listener listener to call at most once
     * @return the connection for this listener
     */
    public Connection once(ConnectionGroup group, Consumer<T> listener) {
        Objects.requireNonNull(group, "group");
        return group.add(once(listener));
    }

    /**
     * Returns a future that completes with the next value of this signal.
     * <p>
     * The listener behind it disconnects as soon as the future completes. Cancelling the future disconnects it
     * too, so a future nobody waits for any more does not stay connected.
     * <p>
     * The future is completed on the thread that fires the signal, and so are the stages you chain with the
     * non-{@code Async} methods ({@code thenAccept} and friends). When that thread matters (an async chat event, a
     * region thread on Folia), use the {@code Async} variants with the executor you need.
     *
     * @return a future for the next value
     */
    public CompletableFuture<T> next() {
        return next(value -> true);
    }

    /**
     * Returns a future that completes with the next value of this signal that a predicate accepts.
     * <p>
     * If the predicate throws, the future completes exceptionally with that exception instead of the exception
     * reaching the code that fires the signal. See {@link #next()} for disconnecting and for the thread the future
     * completes on.
     *
     * @param predicate decides which value completes the future
     * @return a future for the first accepted value
     */
    public CompletableFuture<T> next(Predicate<T> predicate) {
        Objects.requireNonNull(predicate, "predicate");
        CompletableFuture<T> future = new CompletableFuture<>();
        Connection connection = connect(value -> {
            if (future.isDone()) {
                return;
            }
            try {
                if (predicate.test(value)) {
                    future.complete(value);
                }
            } catch (RuntimeException e) {
                future.completeExceptionally(e);
            }
        });
        // Also runs right away if a value completed the future before this line, so nothing stays connected.
        future.whenComplete((value, failure) -> connection.disconnect());
        return future;
    }

    /**
     * Returns a new signal that only carries the values a predicate accepts.
     * <p>
     * The new signal has its own channel; firing on it does not loop back into this signal. Clearing it also
     * detaches it from this signal.
     *
     * @param predicate decides which values pass
     * @return a derived signal of the same payload type
     */
    public Signal<T> filter(Predicate<T> predicate) {
        Objects.requireNonNull(predicate, "predicate");
        Signal<T> child = bus.derivedSignal(eventType());
        child.upstream = connectIf(predicate, child::fire);
        return child;
    }

    /**
     * Returns a new signal that carries every value of this signal converted by a function.
     * <p>
     * The new signal has its own channel. Clearing it also detaches it from this signal.
     *
     * @param resultType payload type of the new signal
     * @param mapper converts a value of this signal
     * @param <R> payload type of the new signal
     * @return a derived signal of the result type
     */
    public <R> Signal<R> map(Class<R> resultType, Function<T, R> mapper) {
        Objects.requireNonNull(mapper, "mapper");
        Signal<R> child = bus.derivedSignal(resultType);
        child.upstream = connect(value -> child.fire(mapper.apply(value)));
        return child;
    }

    /**
     * Delivers a value to every listener of this signal, on the calling thread.
     *
     * @param value value to deliver
     */
    public void fire(T value) {
        bus.fire(key, value);
    }

    /**
     * Counts the listeners connected to this signal's channel.
     *
     * @return number of connected listeners
     */
    public int listenerCount() {
        return bus.listenerCount(key);
    }

    /**
     * Tells whether a value fired on this signal could reach anything: a listener on its channel, or a sub-bus of
     * its bus.
     *
     * @return {@code false} only if firing could not reach any listener
     * @see SignalBus#hasReceivers(SignalKey)
     */
    public boolean hasReceivers() {
        return bus.hasReceivers(key);
    }

    /**
     * Disconnects every listener of this signal's channel, including ones connected through other
     * {@code Signal} instances for the same key. For a signal made by {@link #filter} or {@link #map} it also
     * detaches the signal from its source.
     */
    public void clear() {
        upstream.disconnect();
        bus.clear(key);
    }
}
