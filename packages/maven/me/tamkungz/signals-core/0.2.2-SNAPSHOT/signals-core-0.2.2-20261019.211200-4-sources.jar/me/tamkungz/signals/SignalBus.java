package me.tamkungz.signals;

import foo.zaaarf.geb.GEB;
import foo.zaaarf.geb.api.IBus;
import me.tamkungz.signals.connection.Connection;
import me.tamkungz.signals.connection.ConnectionGroup;
import me.tamkungz.signals.geb.GebBridge;
import me.tamkungz.signals.internal.SignalEnvelope;
import me.tamkungz.signals.internal.SignalRouter;

import java.util.Objects;
import java.util.function.Consumer;

/**
 * Minecraft-friendly facade over GEB.
 * <p>
 * Typed signals live here; custom GEB events, {@code @Listen} listeners and sub-buses are reached
 * through {@link #geb()}.
 */
public final class SignalBus {
    private final IBus gebBus;
    private final GebBridge geb;
    private final SignalRouter router;

    /**
     * Creates a bus on top of a new GEB instance.
     */
    public SignalBus() {
        this(new GEB());
    }

    /**
     * Creates a bus on top of an existing GEB bus.
     *
     * @param gebBus GEB bus to use
     */
    public SignalBus(IBus gebBus) {
        this.gebBus = Objects.requireNonNull(gebBus, "gebBus");
        this.geb = new GebBridge(gebBus);
        this.router = new SignalRouter();
        this.gebBus.registerListener(router);
    }

    /**
     * Creates a bus on top of a new GEB instance.
     *
     * @return a new bus
     */
    public static SignalBus create() {
        return new SignalBus();
    }

    /**
     * Gives direct access to GEB: custom events, {@code @Listen} listeners and sub-buses.
     *
     * @return the GEB bridge of this bus
     */
    public GebBridge geb() {
        return geb;
    }

    /**
     * Returns the signal on the default channel of a payload type.
     *
     * @param eventType payload type
     * @param <T> payload type
     * @return the signal for {@code SignalKey.of(eventType)}
     */
    public <T> Signal<T> signal(Class<T> eventType) {
        return signal(SignalKey.of(eventType));
    }

    /**
     * Returns the signal on a named channel of a payload type.
     *
     * @param eventType payload type
     * @param name channel name
     * @param <T> payload type
     * @return the signal for {@code SignalKey.named(eventType, name)}
     */
    public <T> Signal<T> signal(Class<T> eventType, String name) {
        return signal(SignalKey.named(eventType, name));
    }

    /**
     * Returns the signal on a channel.
     * <p>
     * Signals are cheap views: every {@code Signal} for the same key shares the same listeners.
     *
     * @param key channel key
     * @param <T> payload type
     * @return the signal for the key
     */
    public <T> Signal<T> signal(SignalKey<T> key) {
        return new Signal<>(this, Objects.requireNonNull(key, "key"));
    }

    <T> Signal<T> derivedSignal(Class<T> eventType) {
        return signal(SignalKey.unique(eventType));
    }

    /**
     * Connects a listener to the default channel of a payload type.
     *
     * @param eventType payload type
     * @param listener listener to call
     * @param <T> payload type
     * @return the connection for this listener
     */
    public <T> Connection connect(Class<T> eventType, Consumer<T> listener) {
        return connect(SignalKey.of(eventType), listener);
    }

    /**
     * Connects a listener to a channel.
     *
     * @param key channel key
     * @param listener listener to call
     * @param <T> payload type
     * @return the connection for this listener
     */
    public <T> Connection connect(SignalKey<T> key, Consumer<T> listener) {
        return router.connect(key, listener);
    }

    /**
     * Connects a listener to the default channel of a payload type and tracks it in a group.
     *
     * @param group group that will disconnect the listener
     * @param eventType payload type
     * @param listener listener to call
     * @param <T> payload type
     * @return the connection for this listener
     */
    public <T> Connection connect(ConnectionGroup group, Class<T> eventType, Consumer<T> listener) {
        Objects.requireNonNull(group, "group");
        return group.add(connect(eventType, listener));
    }

    /**
     * Connects a listener to a channel and tracks it in a group.
     *
     * @param group group that will disconnect the listener
     * @param key channel key
     * @param listener listener to call
     * @param <T> payload type
     * @return the connection for this listener
     */
    public <T> Connection connect(ConnectionGroup group, SignalKey<T> key, Consumer<T> listener) {
        Objects.requireNonNull(group, "group");
        return group.add(connect(key, listener));
    }

    /**
     * Connects a listener to the default channel of a payload type that is disconnected after its first value.
     *
     * @param eventType payload type
     * @param listener listener to call at most once
     * @param <T> payload type
     * @return the connection for this listener
     */
    public <T> Connection once(Class<T> eventType, Consumer<T> listener) {
        return once(SignalKey.of(eventType), listener);
    }

    /**
     * Connects a listener to a channel that is disconnected after its first value.
     *
     * @param key channel key
     * @param listener listener to call at most once
     * @param <T> payload type
     * @return the connection for this listener
     */
    public <T> Connection once(SignalKey<T> key, Consumer<T> listener) {
        return router.once(key, listener);
    }

    /**
     * Connects a one-shot listener to the default channel of a payload type and tracks it in a group.
     *
     * @param group group that will disconnect the listener
     * @param eventType payload type
     * @param listener listener to call at most once
     * @param <T> payload type
     * @return the connection for this listener
     */
    public <T> Connection once(ConnectionGroup group, Class<T> eventType, Consumer<T> listener) {
        Objects.requireNonNull(group, "group");
        return group.add(once(eventType, listener));
    }

    /**
     * Connects a one-shot listener to a channel and tracks it in a group.
     *
     * @param group group that will disconnect the listener
     * @param key channel key
     * @param listener listener to call at most once
     * @param <T> payload type
     * @return the connection for this listener
     */
    public <T> Connection once(ConnectionGroup group, SignalKey<T> key, Consumer<T> listener) {
        Objects.requireNonNull(group, "group");
        return group.add(once(key, listener));
    }

    /**
     * Fires a value on the default channel of a payload type.
     *
     * @param eventType payload type
     * @param value value to deliver
     * @param <T> payload type
     */
    public <T> void fire(Class<T> eventType, T value) {
        fire(SignalKey.of(eventType), value);
    }

    /**
     * Fires a value on a channel.
     * <p>
     * Listeners run on the calling thread, in the order they were connected. A throwing listener does not stop
     * the others; once all have run, the router hands the first exception back to GEB, with the rest attached
     * as suppressed exceptions.
     *
     * @param key channel key
     * @param value value to deliver
     * @param <T> payload type
     */
    public <T> void fire(SignalKey<T> key, T value) {
        gebBus.handleEvent(new SignalEnvelope<>(key, value));
    }

    /**
     * Counts the listeners connected to the default channel of a payload type.
     *
     * @param eventType payload type
     * @return number of connected listeners
     */
    public int listenerCount(Class<?> eventType) {
        return listenerCount(SignalKey.of(eventType));
    }

    /**
     * Counts the listeners connected to a channel.
     *
     * @param key channel key
     * @return number of connected listeners
     */
    public int listenerCount(SignalKey<?> key) {
        return router.listenerCount(key);
    }

    /**
     * Disconnects every listener of the default channel of a payload type.
     *
     * @param eventType payload type
     */
    public void clear(Class<?> eventType) {
        clear(SignalKey.of(eventType));
    }

    /**
     * Disconnects every listener of a channel.
     *
     * @param key channel key
     */
    public void clear(SignalKey<?> key) {
        router.clear(key);
    }

    /**
     * Disconnects every listener of every channel on this bus.
     */
    public void clear() {
        router.clear();
    }
}
