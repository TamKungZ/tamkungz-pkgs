package me.tamkungz.signals;

import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;

public final class ConnectionGroup implements Connection {
    private static final int MIN_PRUNE_THRESHOLD = 32;

    private final CopyOnWriteArrayList<Connection> connections = new CopyOnWriteArrayList<>();
    private final AtomicBoolean connected = new AtomicBoolean(true);
    private volatile int pruneThreshold = MIN_PRUNE_THRESHOLD;

    public static ConnectionGroup create() {
        return new ConnectionGroup();
    }

    public static ConnectionGroup of(Connection... connections) {
        Objects.requireNonNull(connections, "connections");
        ConnectionGroup group = create();
        for (Connection connection : connections) {
            group.add(connection);
        }
        return group;
    }

    public <T extends Connection> T add(T connection) {
        Objects.requireNonNull(connection, "connection");
        if (isConnected()) {
            pruneIfLarge();
            connections.add(connection);
            if (!isConnected()) {
                connections.remove(connection);
                connection.disconnect();
            }
        } else {
            connection.disconnect();
        }
        return connection;
    }

    public int size() {
        return connections.size();
    }

    private void pruneIfLarge() {
        if (connections.size() < pruneThreshold) {
            return;
        }
        connections.removeIf(entry -> !entry.isConnected());
        pruneThreshold = Math.max(MIN_PRUNE_THRESHOLD, connections.size() * 2);
    }

    @Override
    public void disconnect() {
        if (!connected.compareAndSet(true, false)) {
            return;
        }

        RuntimeException failure = null;
        for (Connection connection : connections) {
            try {
                connection.disconnect();
            } catch (RuntimeException e) {
                if (failure == null) {
                    failure = e;
                } else {
                    failure.addSuppressed(e);
                }
            }
        }
        connections.clear();
        if (failure != null) {
            throw failure;
        }
    }

    @Override
    public boolean isConnected() {
        return connected.get();
    }
}
