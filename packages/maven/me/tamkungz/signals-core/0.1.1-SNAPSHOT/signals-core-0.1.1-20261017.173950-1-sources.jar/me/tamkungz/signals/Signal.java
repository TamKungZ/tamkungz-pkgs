package me.tamkungz.signals;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * Lightweight signal facade for a single payload type.
 *
 * @param <T> event payload type
 */
public final class Signal<T> {
    private final SignalBus bus;
    private final SignalKey<T> key;
    private volatile Connection upstream = Connection.disconnected();

    Signal(SignalBus bus, SignalKey<T> key) {
        this.bus = Objects.requireNonNull(bus, "bus");
        this.key = Objects.requireNonNull(key, "key");
    }

    public SignalBus bus() {
        return bus;
    }

    public SignalKey<T> key() {
        return key;
    }

    public Class<T> eventType() {
        return key.eventType();
    }

    public Connection connect(Consumer<T> listener) {
        return bus.connect(key, listener);
    }

    public Connection connect(ConnectionGroup group, Consumer<T> listener) {
        Objects.requireNonNull(group, "group");
        return group.add(connect(listener));
    }

    public Connection connectIf(Predicate<T> predicate, Consumer<T> listener) {
        Objects.requireNonNull(predicate, "predicate");
        Objects.requireNonNull(listener, "listener");
        return connect(value -> {
            if (predicate.test(value)) {
                listener.accept(value);
            }
        });
    }

    public Connection connectIf(ConnectionGroup group, Predicate<T> predicate, Consumer<T> listener) {
        Objects.requireNonNull(group, "group");
        return group.add(connectIf(predicate, listener));
    }

    public Connection once(Consumer<T> listener) {
        return bus.once(key, listener);
    }

    public Connection once(ConnectionGroup group, Consumer<T> listener) {
        Objects.requireNonNull(group, "group");
        return group.add(once(listener));
    }

    public Signal<T> filter(Predicate<T> predicate) {
        Objects.requireNonNull(predicate, "predicate");
        Signal<T> child = bus.derivedSignal(eventType());
        child.upstream = connectIf(predicate, child::fire);
        return child;
    }

    public <R> Signal<R> map(Class<R> resultType, Function<T, R> mapper) {
        Objects.requireNonNull(mapper, "mapper");
        Signal<R> child = bus.derivedSignal(resultType);
        child.upstream = connect(value -> child.fire(mapper.apply(value)));
        return child;
    }

    public void fire(T value) {
        bus.fire(key, value);
    }

    public int listenerCount() {
        return bus.listenerCount(key);
    }

    public void clear() {
        upstream.disconnect();
        bus.clear(key);
    }
}
