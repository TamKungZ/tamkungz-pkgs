package me.tamkungz.signals;

import foo.zaaarf.geb.api.IListener;
import foo.zaaarf.geb.api.annotations.Listen;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;

final class SignalRouter implements IListener {
    private final ConcurrentMap<SignalKey<?>, CopyOnWriteArrayList<Subscription<?>>> listeners = new ConcurrentHashMap<>();

    <T> Connection connect(Class<T> eventType, Consumer<T> listener) {
        return connect(SignalKey.of(eventType), listener);
    }

    <T> Connection connect(SignalKey<T> key, Consumer<T> listener) {
        Objects.requireNonNull(key, "key");
        Objects.requireNonNull(listener, "listener");

        Subscription<T> subscription = new Subscription<>(key, listener);
        listeners.compute(key, (ignored, existing) -> {
            CopyOnWriteArrayList<Subscription<?>> list = existing == null ? new CopyOnWriteArrayList<>() : existing;
            list.add(subscription);
            return list;
        });
        return subscription;
    }

    <T> Connection once(Class<T> eventType, Consumer<T> listener) {
        return once(SignalKey.of(eventType), listener);
    }

    <T> Connection once(SignalKey<T> key, Consumer<T> listener) {
        Objects.requireNonNull(listener, "listener");
        AtomicBoolean fired = new AtomicBoolean();
        AtomicReference<Connection> self = new AtomicReference<>();
        Connection connection = connect(key, value -> {
            if (!fired.compareAndSet(false, true)) {
                return;
            }
            Connection current = self.get();
            if (current != null) {
                current.disconnect();
            }
            listener.accept(value);
        });
        self.set(connection);
        if (fired.get()) {
            connection.disconnect();
        }
        return connection;
    }

    int listenerCount(Class<?> eventType) {
        return listenerCount(SignalKey.of(eventType));
    }

    int listenerCount(SignalKey<?> key) {
        List<Subscription<?>> subscriptions = listeners.get(key);
        return subscriptions == null ? 0 : subscriptions.size();
    }

    void clear(Class<?> eventType) {
        clear(SignalKey.of(eventType));
    }

    void clear(SignalKey<?> key) {
        List<Subscription<?>> subscriptions = listeners.remove(key);
        if (subscriptions == null) {
            return;
        }

        for (Subscription<?> subscription : subscriptions) {
            subscription.disconnect();
        }
    }

    void clear() {
        for (SignalKey<?> key : listeners.keySet()) {
            clear(key);
        }
    }

    @Listen
    public void onSignal(SignalEvent<?> event) {
        List<Subscription<?>> subscriptions = listeners.get(event.key());
        if (subscriptions == null) {
            return;
        }

        RuntimeException failure = null;
        for (Subscription<?> subscription : subscriptions) {
            try {
                subscription.accept(event.value());
            } catch (RuntimeException e) {
                if (failure == null) {
                    failure = e;
                } else {
                    failure.addSuppressed(e);
                }
            }
        }
        if (failure != null) {
            throw failure;
        }
    }

    private final class Subscription<T> implements Connection {
        private final SignalKey<T> key;
        private final Consumer<T> listener;
        private final AtomicBoolean connected = new AtomicBoolean(true);

        private Subscription(SignalKey<T> key, Consumer<T> listener) {
            this.key = key;
            this.listener = listener;
        }

        @Override
        public void disconnect() {
            if (!connected.compareAndSet(true, false)) {
                return;
            }

            listeners.computeIfPresent(key, (ignored, subscriptions) -> {
                subscriptions.remove(this);
                return subscriptions.isEmpty() ? null : subscriptions;
            });
        }

        @Override
        public boolean isConnected() {
            return connected.get();
        }

        private void accept(Object value) {
            if (isConnected()) {
                listener.accept(key.cast(value));
            }
        }
    }
}
