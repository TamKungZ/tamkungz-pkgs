package me.tamkungz.signals;

import foo.zaaarf.geb.GEB;
import foo.zaaarf.geb.api.IBus;
import me.tamkungz.signals.connection.Connection;
import me.tamkungz.signals.connection.ConnectionGroup;
import me.tamkungz.signals.geb.GebBridge;
import me.tamkungz.signals.internal.SignalEnvelope;
import me.tamkungz.signals.internal.SignalRouter;

import java.util.Objects;
import java.util.function.Consumer;

/**
 * Minecraft-friendly facade over GEB.
 * <p>
 * Typed signals live here; custom GEB events, {@code @Listen} listeners and sub-buses are reached
 * through {@link #geb()}.
 */
public final class SignalBus {
    private final IBus gebBus;
    private final GebBridge geb;
    private final SignalRouter router;

    /**
     * Creates a bus on top of a new GEB instance.
     */
    public SignalBus() {
        this(new GEB());
    }

    /**
     * Creates a bus on top of an existing GEB bus.
     *
     * @param gebBus GEB bus to use
     */
    public SignalBus(IBus gebBus) {
        this.gebBus = Objects.requireNonNull(gebBus, "gebBus");
        this.geb = new GebBridge(gebBus);
        this.router = new SignalRouter();
        this.gebBus.registerListener(router);
    }

    /**
     * Creates a bus on top of a new GEB instance.
     *
     * @return a new bus
     */
    public static SignalBus create() {
        return new SignalBus();
    }

    /**
     * Gives direct access to GEB: custom events, {@code @Listen} listeners and sub-buses.
     *
     * @return the GEB bridge of this bus
     */
    public GebBridge geb() {
        return geb;
    }

    public <T> Signal<T> signal(Class<T> eventType) {
        return signal(SignalKey.of(eventType));
    }

    public <T> Signal<T> signal(Class<T> eventType, String name) {
        return signal(SignalKey.named(eventType, name));
    }

    public <T> Signal<T> signal(SignalKey<T> key) {
        return new Signal<>(this, Objects.requireNonNull(key, "key"));
    }

    <T> Signal<T> derivedSignal(Class<T> eventType) {
        return signal(SignalKey.unique(eventType));
    }

    public <T> Connection connect(Class<T> eventType, Consumer<T> listener) {
        return connect(SignalKey.of(eventType), listener);
    }

    public <T> Connection connect(SignalKey<T> key, Consumer<T> listener) {
        return router.connect(key, listener);
    }

    public <T> Connection connect(ConnectionGroup group, Class<T> eventType, Consumer<T> listener) {
        Objects.requireNonNull(group, "group");
        return group.add(connect(eventType, listener));
    }

    public <T> Connection once(Class<T> eventType, Consumer<T> listener) {
        return once(SignalKey.of(eventType), listener);
    }

    public <T> Connection once(SignalKey<T> key, Consumer<T> listener) {
        return router.once(key, listener);
    }

    public <T> Connection once(ConnectionGroup group, Class<T> eventType, Consumer<T> listener) {
        Objects.requireNonNull(group, "group");
        return group.add(once(eventType, listener));
    }

    public <T> void fire(Class<T> eventType, T value) {
        fire(SignalKey.of(eventType), value);
    }

    public <T> void fire(SignalKey<T> key, T value) {
        gebBus.handleEvent(new SignalEnvelope<>(key, value));
    }

    public int listenerCount(Class<?> eventType) {
        return listenerCount(SignalKey.of(eventType));
    }

    public int listenerCount(SignalKey<?> key) {
        return router.listenerCount(key);
    }

    public void clear(Class<?> eventType) {
        clear(SignalKey.of(eventType));
    }

    public void clear(SignalKey<?> key) {
        router.clear(key);
    }

    public void clear() {
        router.clear();
    }
}
