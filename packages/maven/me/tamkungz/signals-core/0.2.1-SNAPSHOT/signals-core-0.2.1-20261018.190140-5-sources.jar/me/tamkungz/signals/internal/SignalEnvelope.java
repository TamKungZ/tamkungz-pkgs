package me.tamkungz.signals.internal;

import foo.zaaarf.geb.api.IEvent;
import me.tamkungz.signals.SignalKey;

import java.util.Objects;

/**
 * GEB event that carries one signal payload together with the key it was fired on.
 * <p>
 * Internal: this is the only event type {@link SignalRouter} listens to. It is public because the
 * dispatcher GEB generates for it lives in this package and must be reachable from the bus.
 *
 * @param <T> payload type
 */
public final class SignalEnvelope<T> implements IEvent {
    private final SignalKey<T> key;
    private final T value;

    /**
     * Wraps a payload for the default key of its type.
     *
     * @param eventType payload type
     * @param value payload
     */
    public SignalEnvelope(Class<T> eventType, T value) {
        this(SignalKey.of(eventType), value);
    }

    /**
     * Wraps a payload for the given key.
     *
     * @param key key the payload is fired on
     * @param value payload
     */
    public SignalEnvelope(SignalKey<T> key, T value) {
        this.key = Objects.requireNonNull(key, "key");
        this.value = key.cast(value);
    }

    /**
     * Returns the key the payload is fired on.
     *
     * @return signal key
     */
    public SignalKey<T> key() {
        return key;
    }

    /**
     * Returns the payload type.
     *
     * @return payload class
     */
    public Class<T> eventType() {
        return key.eventType();
    }

    /**
     * Returns the payload.
     *
     * @return payload value
     */
    public T value() {
        return value;
    }
}
