package me.tamkungz.signals.geb;

import foo.zaaarf.geb.api.IBus;
import foo.zaaarf.geb.api.IEvent;
import foo.zaaarf.geb.api.IListener;
import me.tamkungz.signals.connection.Connection;
import me.tamkungz.signals.connection.ConnectionGroup;

import java.util.Objects;

/**
 * Direct access to the GEB bus behind a {@link me.tamkungz.signals.SignalBus}: custom
 * {@link IEvent}s, {@code @Listen} listeners and sub-buses.
 * <p>
 * Obtain it with {@link me.tamkungz.signals.SignalBus#geb()}.
 */
public final class GebBridge {
    private final IBus bus;

    /**
     * Wraps a GEB bus.
     *
     * @param bus bus to expose
     */
    public GebBridge(IBus bus) {
        this.bus = Objects.requireNonNull(bus, "bus");
    }

    /**
     * Returns the underlying GEB bus.
     *
     * @return the raw bus
     */
    public IBus bus() {
        return bus;
    }

    /**
     * Posts an event to every registered listener.
     *
     * @param event event to post
     * @return {@code false} if the event was cancelled, {@code true} otherwise
     */
    public boolean post(IEvent event) {
        return bus.handleEvent(Objects.requireNonNull(event, "event"));
    }

    /**
     * Registers a listener and returns a connection that unregisters it.
     *
     * @param listener listener to register
     * @return connection that unregisters the listener
     */
    public Connection listen(IListener listener) {
        registerListener(listener);
        return new Connection() {
            @Override
            public void disconnect() {
                unregisterListener(listener);
            }

            @Override
            public boolean isConnected() {
                return isRegistered(listener);
            }
        };
    }

    /**
     * Registers a listener and tracks its connection in a group.
     *
     * @param group group that will disconnect the listener
     * @param listener listener to register
     * @return connection that unregisters the listener
     */
    public Connection listen(ConnectionGroup group, IListener listener) {
        Objects.requireNonNull(group, "group");
        return group.add(listen(listener));
    }

    /**
     * Registers a listener.
     *
     * @param listener listener to register
     */
    public void registerListener(IListener listener) {
        bus.registerListener(Objects.requireNonNull(listener, "listener"));
    }

    /**
     * Unregisters a listener.
     *
     * @param listener listener to unregister
     */
    public void unregisterListener(IListener listener) {
        bus.unregisterListener(Objects.requireNonNull(listener, "listener"));
    }

    /**
     * Tells whether a listener is registered.
     *
     * @param listener listener to check
     * @return {@code true} if registered
     */
    public boolean isRegistered(IListener listener) {
        return bus.isRegistered(Objects.requireNonNull(listener, "listener"));
    }

    /**
     * Registers a sub-bus and returns a connection that unregisters it.
     *
     * @param subBus bus to forward events to
     * @param priority sub-bus priority
     * @return connection that unregisters the sub-bus
     */
    public Connection subBus(IBus subBus, int priority) {
        registerSubBus(subBus, priority);
        return new Connection() {
            @Override
            public void disconnect() {
                unregisterSubBus(subBus);
            }

            @Override
            public boolean isConnected() {
                return isRegistered(subBus);
            }
        };
    }

    /**
     * Registers a sub-bus and tracks its connection in a group.
     *
     * @param group group that will unregister the sub-bus
     * @param subBus bus to forward events to
     * @param priority sub-bus priority
     * @return connection that unregisters the sub-bus
     */
    public Connection subBus(ConnectionGroup group, IBus subBus, int priority) {
        Objects.requireNonNull(group, "group");
        return group.add(subBus(subBus, priority));
    }

    /**
     * Registers a sub-bus.
     *
     * @param subBus bus to forward events to
     * @param priority sub-bus priority
     */
    public void registerSubBus(IBus subBus, int priority) {
        bus.registerSubBus(Objects.requireNonNull(subBus, "subBus"), priority);
    }

    /**
     * Unregisters a sub-bus.
     *
     * @param subBus bus to stop forwarding to
     */
    public void unregisterSubBus(IBus subBus) {
        bus.unregisterSubBus(Objects.requireNonNull(subBus, "subBus"));
    }

    /**
     * Tells whether a sub-bus is registered.
     *
     * @param subBus bus to check
     * @return {@code true} if registered
     */
    public boolean isRegistered(IBus subBus) {
        return bus.isRegistered(Objects.requireNonNull(subBus, "subBus"));
    }
}
