package me.tamkungz.signals;

import java.util.Objects;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Identifies one signal channel: a payload type plus a name.
 * <p>
 * Keys with the same type and name address the same channel; derived keys created by
 * {@link Signal#filter} and {@link Signal#map} are always unique.
 *
 * @param <T> payload type
 */
public final class SignalKey<T> {
    private static final AtomicLong NEXT_ID = new AtomicLong();

    private final Class<T> eventType;
    private final String name;
    private final long uniqueId;

    private SignalKey(Class<T> eventType, String name, long uniqueId) {
        this.eventType = Objects.requireNonNull(eventType, "eventType");
        this.name = Objects.requireNonNull(name, "name");
        this.uniqueId = uniqueId;
    }

    public static <T> SignalKey<T> of(Class<T> eventType) {
        return named(eventType, "default");
    }

    public static <T> SignalKey<T> named(Class<T> eventType, String name) {
        return new SignalKey<>(eventType, name, 0L);
    }

    static <T> SignalKey<T> unique(Class<T> eventType) {
        long id = NEXT_ID.incrementAndGet();
        return new SignalKey<>(eventType, "derived-" + id, id);
    }

    public Class<T> eventType() {
        return eventType;
    }

    public String name() {
        return name;
    }

    /**
     * Casts a value to this key's payload type.
     *
     * @param value value to cast, may be {@code null}
     * @return the value as {@code T}
     * @throws ClassCastException if the value is not an instance of the payload type
     */
    public T cast(Object value) {
        return eventType.cast(value);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof SignalKey)) {
            return false;
        }
        SignalKey<?> key = (SignalKey<?>) other;
        return uniqueId == key.uniqueId && eventType.equals(key.eventType) && name.equals(key.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(eventType, name, uniqueId);
    }

    @Override
    public String toString() {
        return eventType.getName() + "#" + name;
    }
}
