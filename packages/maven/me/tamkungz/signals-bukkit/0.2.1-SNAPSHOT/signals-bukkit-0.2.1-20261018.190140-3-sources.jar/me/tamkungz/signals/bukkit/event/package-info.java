/**
 * Fluent Bukkit event options and per-domain shortcuts (players, blocks, entities, inventories).
 */
package me.tamkungz.signals.bukkit.event;
