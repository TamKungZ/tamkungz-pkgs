package me.tamkungz.signals.bukkit.event;

import me.tamkungz.signals.Signal;
import me.tamkungz.signals.connection.Connection;
import me.tamkungz.signals.connection.ConnectionGroup;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Predicate;

/**
 * Fluent options (priority, cancellation) for listening to one Bukkit event type.
 * <p>
 * Pick options, then either call {@link #signal()} or connect a listener directly.
 *
 * @param <T> Bukkit event type
 */
public final class EventSignalBuilder<T extends Event> {
    private final EventSignalSource source;
    private final Class<T> eventType;
    private EventPriority priority = EventPriority.NORMAL;
    private boolean ignoreCancelled;

    /**
     * Creates a builder; prefer {@link EventSignalSource#on(Class)}.
     *
     * @param source where the signal comes from
     * @param eventType Bukkit event type
     */
    public EventSignalBuilder(EventSignalSource source, Class<T> eventType) {
        this.source = Objects.requireNonNull(source, "source");
        this.eventType = Objects.requireNonNull(eventType, "eventType");
    }

    public EventSignalBuilder<T> priority(EventPriority priority) {
        this.priority = Objects.requireNonNull(priority, "priority");
        return this;
    }

    public EventSignalBuilder<T> lowest() {
        return priority(EventPriority.LOWEST);
    }

    public EventSignalBuilder<T> low() {
        return priority(EventPriority.LOW);
    }

    public EventSignalBuilder<T> normal() {
        return priority(EventPriority.NORMAL);
    }

    public EventSignalBuilder<T> high() {
        return priority(EventPriority.HIGH);
    }

    public EventSignalBuilder<T> highest() {
        return priority(EventPriority.HIGHEST);
    }

    public EventSignalBuilder<T> monitor() {
        return priority(EventPriority.MONITOR);
    }

    public EventSignalBuilder<T> ignoreCancelled() {
        this.ignoreCancelled = true;
        return this;
    }

    public EventSignalBuilder<T> includeCancelled() {
        this.ignoreCancelled = false;
        return this;
    }

    public Signal<T> signal() {
        return source.signal(eventType, priority, ignoreCancelled);
    }

    public Connection connect(Consumer<T> listener) {
        return signal().connect(listener);
    }

    public Connection connect(ConnectionGroup group, Consumer<T> listener) {
        return signal().connect(group, listener);
    }

    public Connection connectIf(Predicate<T> predicate, Consumer<T> listener) {
        return signal().connectIf(predicate, listener);
    }

    public Connection connectIf(ConnectionGroup group, Predicate<T> predicate, Consumer<T> listener) {
        return signal().connectIf(group, predicate, listener);
    }

    public Connection once(Consumer<T> listener) {
        return signal().once(listener);
    }

    public Connection once(ConnectionGroup group, Consumer<T> listener) {
        return signal().once(group, listener);
    }
}
