package me.tamkungz.signals.bukkit.event;

import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;

import java.util.Objects;

/**
 * Shortcuts for common Bukkit block events, reached with {@code BukkitSignals#blocks()}.
 * <p>
 * Each method is the same as {@link EventSignalSource#on(Class)} for the named event class;
 * anything not listed here is still available through that method.
 */
public final class BlockSignals {
    private final EventSignalSource source;

    /**
     * Creates the shortcuts; prefer {@code BukkitSignals#blocks()}.
     *
     * @param source where the signals come from
     */
    public BlockSignals(EventSignalSource source) {
        this.source = Objects.requireNonNull(source, "source");
    }

    /**
     * Listens to {@link BlockBreakEvent}.
     *
     * @return a builder for priority and cancellation options
     */
    public EventSignalBuilder<BlockBreakEvent> breakBlock() {
        return source.on(BlockBreakEvent.class);
    }

    /**
     * Listens to {@link BlockPlaceEvent}.
     *
     * @return a builder for priority and cancellation options
     */
    public EventSignalBuilder<BlockPlaceEvent> placeBlock() {
        return source.on(BlockPlaceEvent.class);
    }
}
