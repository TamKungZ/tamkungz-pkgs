package me.tamkungz.signals.bukkit;

import me.tamkungz.signals.Signal;
import me.tamkungz.signals.SignalBus;
import me.tamkungz.signals.bukkit.event.BlockSignals;
import me.tamkungz.signals.bukkit.event.EntitySignals;
import me.tamkungz.signals.bukkit.event.EventSignalSource;
import me.tamkungz.signals.bukkit.event.InventorySignals;
import me.tamkungz.signals.bukkit.event.PlayerSignals;
import me.tamkungz.signals.bukkit.internal.EventSignalRegistry;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;
import org.bukkit.plugin.Plugin;

import java.util.Objects;

/**
 * Small bridge from Bukkit events to GEB-backed signals.
 * <p>
 * Common events are grouped by domain: {@link #players()}, {@link #blocks()}, {@link #entities()}
 * and {@link #inventories()}. Any other event type is available through {@link #on(Class)}.
 */
public final class BukkitSignals implements EventSignalSource {
    private final SignalBus bus;
    private final EventSignalRegistry registry;
    private final PlayerSignals players;
    private final BlockSignals blocks;
    private final EntitySignals entities;
    private final InventorySignals inventories;

    private BukkitSignals(Plugin plugin, SignalBus bus) {
        Objects.requireNonNull(plugin, "plugin");
        this.bus = Objects.requireNonNull(bus, "bus");
        this.registry = new EventSignalRegistry(plugin, bus);
        this.players = new PlayerSignals(this);
        this.blocks = new BlockSignals(this);
        this.entities = new EntitySignals(this);
        this.inventories = new InventorySignals(this);
    }

    /**
     * Creates a bridge with its own signal bus.
     *
     * @param plugin plugin that owns the Bukkit listeners
     * @return a new bridge
     */
    public static BukkitSignals create(Plugin plugin) {
        return new BukkitSignals(plugin, SignalBus.create());
    }

    /**
     * Creates a bridge on an existing signal bus.
     *
     * @param plugin plugin that owns the Bukkit listeners
     * @param bus bus the signals live on
     * @return a new bridge
     */
    public static BukkitSignals create(Plugin plugin, SignalBus bus) {
        return new BukkitSignals(plugin, bus);
    }

    /**
     * Returns the bridge shared by every plugin through the installed SignalsLib plugin.
     *
     * @return the shared bridge
     */
    public static BukkitSignals shared() {
        return SignalsPlugin.getInstance().signals();
    }

    /**
     * Returns the signal bus shared by every plugin through the installed SignalsLib plugin.
     *
     * @return the shared bus
     */
    public static SignalBus sharedBus() {
        return SignalsPlugin.getInstance().bus();
    }

    /**
     * Creates a private bridge for a single event type and returns its signal.
     *
     * @param plugin plugin that owns the Bukkit listener
     * @param eventType Bukkit event type
     * @param priority priority the Bukkit listener runs at
     * @param ignoreCancelled whether cancelled events are skipped
     * @param <T> event type
     * @return the signal for that event type
     */
    public static <T extends Event> Signal<T> standaloneSignal(
            Plugin plugin,
            Class<T> eventType,
            EventPriority priority,
            boolean ignoreCancelled
    ) {
        return create(plugin).signal(eventType, priority, ignoreCancelled);
    }

    /**
     * Creates a private bridge for a single event type at {@link EventPriority#NORMAL} and returns its signal.
     *
     * @param plugin plugin that owns the Bukkit listener
     * @param eventType Bukkit event type
     * @param <T> event type
     * @return the signal for that event type
     */
    public static <T extends Event> Signal<T> standaloneSignal(Plugin plugin, Class<T> eventType) {
        return standaloneSignal(plugin, eventType, EventPriority.NORMAL, false);
    }

    /**
     * Returns the signal bus behind this bridge.
     *
     * @return the signal bus
     */
    public SignalBus bus() {
        return bus;
    }

    @Override
    public <T extends Event> Signal<T> signal(Class<T> eventType, EventPriority priority, boolean ignoreCancelled) {
        return registry.signal(eventType, priority, ignoreCancelled);
    }

    /**
     * Returns shortcuts for player events.
     *
     * @return player signals
     */
    public PlayerSignals players() {
        return players;
    }

    /**
     * Returns shortcuts for block events.
     *
     * @return block signals
     */
    public BlockSignals blocks() {
        return blocks;
    }

    /**
     * Returns shortcuts for entity events.
     *
     * @return entity signals
     */
    public EntitySignals entities() {
        return entities;
    }

    /**
     * Returns shortcuts for inventory events.
     *
     * @return inventory signals
     */
    public InventorySignals inventories() {
        return inventories;
    }
}
