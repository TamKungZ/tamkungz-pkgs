/**
 * Bukkit/Spigot entry points: {@link me.tamkungz.signals.bukkit.BukkitSignals} and the
 * {@link me.tamkungz.signals.bukkit.SignalsPlugin} that shares one bridge between plugins.
 */
package me.tamkungz.signals.bukkit;
