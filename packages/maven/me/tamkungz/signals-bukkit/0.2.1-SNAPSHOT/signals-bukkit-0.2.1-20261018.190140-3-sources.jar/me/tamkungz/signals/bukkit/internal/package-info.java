/**
 * Implementation details of the Bukkit bridge. Not part of the public API and may change without notice.
 */
package me.tamkungz.signals.bukkit.internal;
