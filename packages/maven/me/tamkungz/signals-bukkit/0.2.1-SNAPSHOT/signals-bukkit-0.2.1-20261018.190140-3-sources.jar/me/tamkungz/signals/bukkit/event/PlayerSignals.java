package me.tamkungz.signals.bukkit.event;

import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

import java.util.Objects;

/**
 * Shortcuts for common Bukkit player events, reached with {@code BukkitSignals#players()}.
 * <p>
 * Each method is the same as {@link EventSignalSource#on(Class)} for the named event class;
 * anything not listed here is still available through that method.
 */
public final class PlayerSignals {
    private final EventSignalSource source;

    /**
     * Creates the shortcuts; prefer {@code BukkitSignals#players()}.
     *
     * @param source where the signals come from
     */
    public PlayerSignals(EventSignalSource source) {
        this.source = Objects.requireNonNull(source, "source");
    }

    /**
     * Listens to {@link PlayerJoinEvent}.
     *
     * @return a builder for priority and cancellation options
     */
    public EventSignalBuilder<PlayerJoinEvent> join() {
        return source.on(PlayerJoinEvent.class);
    }

    /**
     * Listens to {@link PlayerQuitEvent}.
     *
     * @return a builder for priority and cancellation options
     */
    public EventSignalBuilder<PlayerQuitEvent> quit() {
        return source.on(PlayerQuitEvent.class);
    }

    /**
     * Listens to {@link PlayerKickEvent}.
     *
     * @return a builder for priority and cancellation options
     */
    public EventSignalBuilder<PlayerKickEvent> kick() {
        return source.on(PlayerKickEvent.class);
    }

    /**
     * Listens to {@link PlayerMoveEvent}.
     *
     * @return a builder for priority and cancellation options
     */
    public EventSignalBuilder<PlayerMoveEvent> move() {
        return source.on(PlayerMoveEvent.class);
    }

    /**
     * Listens to {@link PlayerTeleportEvent}.
     *
     * @return a builder for priority and cancellation options
     */
    public EventSignalBuilder<PlayerTeleportEvent> teleport() {
        return source.on(PlayerTeleportEvent.class);
    }

    /**
     * Listens to {@link PlayerInteractEvent}.
     *
     * @return a builder for priority and cancellation options
     */
    public EventSignalBuilder<PlayerInteractEvent> interact() {
        return source.on(PlayerInteractEvent.class);
    }

    /**
     * Listens to {@link PlayerDeathEvent}.
     *
     * @return a builder for priority and cancellation options
     */
    public EventSignalBuilder<PlayerDeathEvent> death() {
        return source.on(PlayerDeathEvent.class);
    }

    /**
     * Listens to {@link PlayerRespawnEvent}.
     *
     * @return a builder for priority and cancellation options
     */
    public EventSignalBuilder<PlayerRespawnEvent> respawn() {
        return source.on(PlayerRespawnEvent.class);
    }

    /**
     * Listens to {@link PlayerCommandPreprocessEvent}.
     *
     * @return a builder for priority and cancellation options
     */
    public EventSignalBuilder<PlayerCommandPreprocessEvent> command() {
        return source.on(PlayerCommandPreprocessEvent.class);
    }
}
