package me.tamkungz.signals.bukkit.event;

import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;

import java.util.Objects;

/**
 * Shortcuts for common Bukkit entity events, reached with {@code BukkitSignals#entities()}.
 * <p>
 * Each method is the same as {@link EventSignalSource#on(Class)} for the named event class;
 * anything not listed here is still available through that method.
 */
public final class EntitySignals {
    private final EventSignalSource source;

    /**
     * Creates the shortcuts; prefer {@code BukkitSignals#entities()}.
     *
     * @param source where the signals come from
     */
    public EntitySignals(EventSignalSource source) {
        this.source = Objects.requireNonNull(source, "source");
    }

    /**
     * Listens to {@link EntityDamageEvent}.
     *
     * @return a builder for priority and cancellation options
     */
    public EventSignalBuilder<EntityDamageEvent> damage() {
        return source.on(EntityDamageEvent.class);
    }

    /**
     * Listens to {@link EntityDeathEvent}.
     *
     * @return a builder for priority and cancellation options
     */
    public EventSignalBuilder<EntityDeathEvent> death() {
        return source.on(EntityDeathEvent.class);
    }
}
