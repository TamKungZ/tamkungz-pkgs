package me.tamkungz.signals.bukkit.event;

import me.tamkungz.signals.Signal;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;

/**
 * Supplies the {@link Signal} that carries a Bukkit event for a given priority and cancellation mode.
 * <p>
 * The fluent {@link EventSignalBuilder} and the per-domain accessors depend on this interface only,
 * which keeps them free of {@code BukkitSignals} itself.
 */
public interface EventSignalSource {
    /**
     * Returns the signal for an event type with the given options.
     *
     * @param eventType Bukkit event type
     * @param priority priority the underlying Bukkit listener runs at
     * @param ignoreCancelled whether cancelled events are skipped
     * @param <T> event type
     * @return the signal for that combination
     */
    <T extends Event> Signal<T> signal(Class<T> eventType, EventPriority priority, boolean ignoreCancelled);

    /**
     * Returns the signal for an event type at {@link EventPriority#NORMAL}, including cancelled events.
     *
     * @param eventType Bukkit event type
     * @param <T> event type
     * @return the default signal for the event type
     */
    default <T extends Event> Signal<T> signal(Class<T> eventType) {
        return signal(eventType, EventPriority.NORMAL, false);
    }

    /**
     * Starts a fluent configuration for an event type.
     *
     * @param eventType Bukkit event type
     * @param <T> event type
     * @return a builder for priority and cancellation options
     */
    default <T extends Event> EventSignalBuilder<T> on(Class<T> eventType) {
        return new EventSignalBuilder<>(this, eventType);
    }
}
