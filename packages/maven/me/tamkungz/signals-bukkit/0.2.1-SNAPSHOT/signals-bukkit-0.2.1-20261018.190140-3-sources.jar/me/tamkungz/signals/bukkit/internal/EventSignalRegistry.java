package me.tamkungz.signals.bukkit.internal;

import me.tamkungz.signals.Signal;
import me.tamkungz.signals.SignalBus;
import me.tamkungz.signals.SignalKey;
import org.bukkit.Bukkit;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.plugin.EventExecutor;
import org.bukkit.plugin.Plugin;

import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Registers one Bukkit listener per event type, priority and cancellation mode, and caches the
 * {@link Signal} each of them feeds.
 * <p>
 * Internal: use {@code BukkitSignals} instead.
 */
public final class EventSignalRegistry {
    private final Plugin plugin;
    private final SignalBus bus;
    private final Map<EventChannel, Signal<? extends Event>> channels = new ConcurrentHashMap<>();

    /**
     * Creates a registry that registers Bukkit listeners for a plugin and fires onto a bus.
     *
     * @param plugin plugin that owns the Bukkit listeners
     * @param bus bus the signals live on
     */
    public EventSignalRegistry(Plugin plugin, SignalBus bus) {
        this.plugin = Objects.requireNonNull(plugin, "plugin");
        this.bus = Objects.requireNonNull(bus, "bus");
    }

    /**
     * Returns the signal for an event type with the given options, registering the Bukkit listener on
     * first use.
     *
     * @param eventType Bukkit event type
     * @param priority priority the Bukkit listener runs at
     * @param ignoreCancelled whether cancelled events are skipped
     * @param <T> event type
     * @return the signal for that combination
     */
    public <T extends Event> Signal<T> signal(Class<T> eventType, EventPriority priority, boolean ignoreCancelled) {
        Objects.requireNonNull(eventType, "eventType");
        Objects.requireNonNull(priority, "priority");
        EventChannel channel = new EventChannel(eventType, priority, ignoreCancelled);
        @SuppressWarnings("unchecked")
        Signal<T> signal = (Signal<T>) channels.computeIfAbsent(channel, ignored -> register(
                eventType,
                priority,
                ignoreCancelled
        ));
        return signal;
    }

    private <T extends Event> Signal<T> register(Class<T> eventType, EventPriority priority, boolean ignoreCancelled) {
        SignalKey<T> signalKey = priority == EventPriority.NORMAL && !ignoreCancelled
                ? SignalKey.of(eventType)
                : SignalKey.named(eventType, "bukkit:" + priority.name() + ":" + ignoreCancelled);
        Signal<T> signal = bus.signal(signalKey);
        Listener listener = new Listener() {};
        EventExecutor executor = (ignored, event) -> {
            if (eventType.isInstance(event)) {
                signal.fire(eventType.cast(event));
            }
        };

        Bukkit.getPluginManager().registerEvent(
                eventType,
                listener,
                priority,
                executor,
                plugin,
                ignoreCancelled
        );

        return signal;
    }

    /** One Bukkit listener registration: event type plus priority plus cancellation mode. */
    private static final class EventChannel {
        private final Class<? extends Event> eventType;
        private final EventPriority priority;
        private final boolean ignoreCancelled;

        private EventChannel(Class<? extends Event> eventType, EventPriority priority, boolean ignoreCancelled) {
            this.eventType = eventType;
            this.priority = priority;
            this.ignoreCancelled = ignoreCancelled;
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof EventChannel)) {
                return false;
            }
            EventChannel channel = (EventChannel) other;
            return ignoreCancelled == channel.ignoreCancelled
                    && eventType.equals(channel.eventType)
                    && priority == channel.priority;
        }

        @Override
        public int hashCode() {
            return Objects.hash(eventType, priority, ignoreCancelled);
        }
    }
}
