package me.tamkungz.signals.bukkit.event;

import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;

import java.util.Objects;

/**
 * Shortcuts for common Bukkit inventory events, reached with {@code BukkitSignals#inventories()}.
 * <p>
 * Each method is the same as {@link EventSignalSource#on(Class)} for the named event class;
 * anything not listed here is still available through that method.
 */
public final class InventorySignals {
    private final EventSignalSource source;

    /**
     * Creates the shortcuts; prefer {@code BukkitSignals#inventories()}.
     *
     * @param source where the signals come from
     */
    public InventorySignals(EventSignalSource source) {
        this.source = Objects.requireNonNull(source, "source");
    }

    /**
     * Listens to {@link InventoryClickEvent}.
     *
     * @return a builder for priority and cancellation options
     */
    public EventSignalBuilder<InventoryClickEvent> click() {
        return source.on(InventoryClickEvent.class);
    }

    /**
     * Listens to {@link InventoryCloseEvent}.
     *
     * @return a builder for priority and cancellation options
     */
    public EventSignalBuilder<InventoryCloseEvent> close() {
        return source.on(InventoryCloseEvent.class);
    }
}
