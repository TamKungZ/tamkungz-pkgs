package me.tamkungz.signals.bukkit.event;

import me.tamkungz.signals.Signal;
import me.tamkungz.signals.connection.Connection;
import me.tamkungz.signals.connection.ConnectionGroup;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Predicate;

/**
 * Fluent options (priority, cancellation) for listening to one Bukkit event type.
 * <p>
 * Pick options, then either call {@link #signal()} or connect a listener directly.
 *
 * @param <T> Bukkit event type
 */
public final class EventSignalBuilder<T extends Event> {
    private final EventSignalSource source;
    private final Class<T> eventType;
    private EventPriority priority = EventPriority.NORMAL;
    private boolean ignoreCancelled;

    /**
     * Creates a builder; prefer {@link EventSignalSource#on(Class)}.
     *
     * @param source where the signal comes from
     * @param eventType Bukkit event type
     */
    public EventSignalBuilder(EventSignalSource source, Class<T> eventType) {
        this.source = Objects.requireNonNull(source, "source");
        this.eventType = Objects.requireNonNull(eventType, "eventType");
    }

    /**
     * Sets the priority the underlying Bukkit listener runs at; the default is {@link EventPriority#NORMAL}.
     *
     * @param priority Bukkit event priority
     * @return this builder
     */
    public EventSignalBuilder<T> priority(EventPriority priority) {
        this.priority = Objects.requireNonNull(priority, "priority");
        return this;
    }

    /**
     * Same as {@code priority(EventPriority.LOWEST)}.
     *
     * @return this builder
     */
    public EventSignalBuilder<T> lowest() {
        return priority(EventPriority.LOWEST);
    }

    /**
     * Same as {@code priority(EventPriority.LOW)}.
     *
     * @return this builder
     */
    public EventSignalBuilder<T> low() {
        return priority(EventPriority.LOW);
    }

    /**
     * Same as {@code priority(EventPriority.NORMAL)}.
     *
     * @return this builder
     */
    public EventSignalBuilder<T> normal() {
        return priority(EventPriority.NORMAL);
    }

    /**
     * Same as {@code priority(EventPriority.HIGH)}.
     *
     * @return this builder
     */
    public EventSignalBuilder<T> high() {
        return priority(EventPriority.HIGH);
    }

    /**
     * Same as {@code priority(EventPriority.HIGHEST)}.
     *
     * @return this builder
     */
    public EventSignalBuilder<T> highest() {
        return priority(EventPriority.HIGHEST);
    }

    /**
     * Same as {@code priority(EventPriority.MONITOR)}. Listeners at this priority must not change the event.
     *
     * @return this builder
     */
    public EventSignalBuilder<T> monitor() {
        return priority(EventPriority.MONITOR);
    }

    /**
     * Skips events that an earlier listener already cancelled.
     *
     * @return this builder
     */
    public EventSignalBuilder<T> ignoreCancelled() {
        this.ignoreCancelled = true;
        return this;
    }

    /**
     * Delivers cancelled events too; this is the default.
     *
     * @return this builder
     */
    public EventSignalBuilder<T> includeCancelled() {
        this.ignoreCancelled = false;
        return this;
    }

    /**
     * Returns the signal for the chosen options, registering the Bukkit listener on first use.
     *
     * @return the signal for this event type, priority and cancellation mode
     */
    public Signal<T> signal() {
        return source.signal(eventType, priority, ignoreCancelled);
    }

    /**
     * Connects a listener to the signal for the chosen options.
     *
     * @param listener listener to call for every event
     * @return the connection for this listener
     */
    public Connection connect(Consumer<T> listener) {
        return signal().connect(listener);
    }

    /**
     * Connects a listener and tracks it in a group.
     *
     * @param group group that will disconnect the listener
     * @param listener listener to call for every event
     * @return the connection for this listener
     */
    public Connection connect(ConnectionGroup group, Consumer<T> listener) {
        return signal().connect(group, listener);
    }

    /**
     * Connects a listener that only receives the events a predicate accepts.
     *
     * @param predicate decides which events reach the listener
     * @param listener listener to call for accepted events
     * @return the connection for this listener
     */
    public Connection connectIf(Predicate<T> predicate, Consumer<T> listener) {
        return signal().connectIf(predicate, listener);
    }

    /**
     * Connects a filtered listener and tracks it in a group.
     *
     * @param group group that will disconnect the listener
     * @param predicate decides which events reach the listener
     * @param listener listener to call for accepted events
     * @return the connection for this listener
     */
    public Connection connectIf(ConnectionGroup group, Predicate<T> predicate, Consumer<T> listener) {
        return signal().connectIf(group, predicate, listener);
    }

    /**
     * Connects a listener that is disconnected after its first event.
     *
     * @param listener listener to call at most once
     * @return the connection for this listener
     */
    public Connection once(Consumer<T> listener) {
        return signal().once(listener);
    }

    /**
     * Connects a one-shot listener and tracks it in a group.
     *
     * @param group group that will disconnect the listener
     * @param listener listener to call at most once
     * @return the connection for this listener
     */
    public Connection once(ConnectionGroup group, Consumer<T> listener) {
        return signal().once(group, listener);
    }
}
