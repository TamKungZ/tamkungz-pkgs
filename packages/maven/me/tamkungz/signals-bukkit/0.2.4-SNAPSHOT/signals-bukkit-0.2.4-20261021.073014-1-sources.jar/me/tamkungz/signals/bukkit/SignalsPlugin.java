package me.tamkungz.signals.bukkit;

import me.tamkungz.signals.SignalBus;
import me.tamkungz.signals.connection.Connection;
import me.tamkungz.signals.connection.ConnectionGroup;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Bukkit plugin entrypoint for servers that want to load SignalsLib as a shared library.
 */
public final class SignalsPlugin extends JavaPlugin {
    private BukkitSignals signals;
    private ConnectionGroup connections;

    @Override
    public void onLoad() {
        connections = ConnectionGroup.create();
        signals = BukkitSignals.create(this);
    }

    @Override
    public void onDisable() {
        if (connections != null) {
            connections.disconnect();
        }
        if (signals != null) {
            signals.bus().clear();
        }
    }

    /**
     * Returns the loaded SignalsLib plugin.
     *
     * @return the plugin instance
     */
    public static SignalsPlugin getInstance() {
        return getPlugin(SignalsPlugin.class);
    }

    /**
     * Returns the bridge shared by every plugin.
     *
     * @return the shared bridge
     */
    public BukkitSignals signals() {
        return signals;
    }

    /**
     * Returns the signal bus shared by every plugin.
     *
     * @return the shared bus
     */
    public SignalBus bus() {
        return signals.bus();
    }

    /**
     * Returns the group that is disconnected when SignalsLib disables.
     *
     * @return the plugin's connection group
     */
    public ConnectionGroup connections() {
        return connections;
    }

    /**
     * Tracks a connection so it is disconnected when SignalsLib disables.
     *
     * @param connection connection to track
     * @param <T> connection type
     * @return the same connection
     */
    public <T extends Connection> T track(T connection) {
        return connections.add(connection);
    }
}
