# SignalsLib

A tiny Java signal/event library with optional Bukkit/Spigot, Folia, BungeeCord/Waterfall and Velocity
integration, backed by [GEB](https://central.sonatype.com/artifact/foo.zaaarf.geb/core).

- Minecraft: 1.16.5 through 26.x (Spigot and Paper); Folia and Paper 1.20 or newer for `signals-folia`
- Proxies: BungeeCord, Waterfall and Velocity 3.x
- Server JVM: Java 17 or newer
- Minimum JDK to build: 17
- Bukkit/Spigot API baseline: 1.16.5
- Group: `me.tamkungz`
- Author: TamKungZ_ <dev@tamkungz.me>
- Website: https://dev.tamkungz.me
- Download: https://modrinth.com/plugin/signalslib or https://hangar.papermc.io/TamKungZ_/SignalsLib

## Modules

- `signals-core` — pure Java, no Minecraft dependency
- `signals-bukkit` — Bukkit/Spigot bridge
- `signals-folia` — Folia (regionised multithreading) support on top of `signals-bukkit`
- `signals-bungeecord` — BungeeCord and Waterfall bridge
- `signals-velocity` — Velocity bridge

## Packages

`signals-core`

- `me.tamkungz.signals` — `SignalBus`, `Signal`, `SignalKey`
- `me.tamkungz.signals.connection` — `Connection`, `ConnectionGroup`
- `me.tamkungz.signals.geb` — `GebBridge`, direct GEB access
- `me.tamkungz.signals.internal` — implementation details, not API

`signals-bukkit`

- `me.tamkungz.signals.bukkit` — `BukkitSignals`, `SignalsPlugin`
- `me.tamkungz.signals.bukkit.event` — `EventSignalBuilder`, `EventSignalSource` and the `PlayerSignals`,
  `BlockSignals`, `EntitySignals`, `InventorySignals` shortcuts
- `me.tamkungz.signals.bukkit.internal` — implementation details, not API

`signals-folia`

- `me.tamkungz.signals.folia` — `FoliaSignals`, `FoliaScheduler`

`signals-bungeecord`

- `me.tamkungz.signals.bungee` — `BungeeSignals`, `SignalsBungeePlugin`
- `me.tamkungz.signals.bungee.event` — `EventSignalSource` and the `PlayerSignals`, `ServerSignals`,
  `ProxySignals` shortcuts
- `me.tamkungz.signals.bungee.internal` — implementation details, not API

`signals-velocity`

- `me.tamkungz.signals.velocity` — `VelocitySignals`, `SignalsVelocityPlugin`
- `me.tamkungz.signals.velocity.event` — `EventSignalBuilder` and the `PlayerSignals`, `ServerSignals`,
  `ProxySignals` shortcuts
- `me.tamkungz.signals.velocity.internal` — implementation details, not API

## Repository

Stable Maven repository:

```gradle
repositories {
    maven { url = 'https://packages.tamkungz.me/maven/' }
}
```

Mirror:

```gradle
repositories {
    maven { url = 'https://repo.tamkungz.me' }
}
```

```gradle
dependencies {
    compileOnly 'me.tamkungz:signals-bukkit:0.2.4-SNAPSHOT'
    // or, for the other platforms:
    // compileOnly 'me.tamkungz:signals-folia:0.2.4-SNAPSHOT'
    // compileOnly 'me.tamkungz:signals-bungeecord:0.2.4-SNAPSHOT'
    // compileOnly 'me.tamkungz:signals-velocity:0.2.4-SNAPSHOT'
}
```

## Core API

```java
SignalBus bus = SignalBus.create();
Signal<String> signal = bus.signal(String.class);

Connection connection = signal.connect(message -> {
    System.out.println("Got: " + message);
});

signal.fire("hello");
connection.disconnect();
```

Signals can be filtered, mapped, named, and grouped for cleanup:

```java
ConnectionGroup cleanup = ConnectionGroup.create();

Signal<String> chat = bus.signal(String.class, "chat");

chat.connectIf(cleanup, message -> message.startsWith("!"), message -> {
    System.out.println("Command-ish message: " + message);
});

Signal<Integer> lengths = chat.map(Integer.class, String::length);

lengths.filter(length -> length > 12)
    .connect(cleanup, length -> System.out.println("Long message: " + length));

cleanup.disconnect();
```

Wait for one value with a `CompletableFuture`. The listener behind it disconnects when the future completes or
is cancelled:

```java
bus.signal(String.class, "chat")
    .next(message -> message.startsWith("!"))
    .thenAccept(message -> System.out.println("First command-ish message: " + message));
```

`connectOn` hands every value to an `Executor`, so a listener can run on the thread it needs instead of the thread
that fired the signal. A value still queued when the connection is disconnected is skipped:

```java
signal.connectOn(executor, value -> handle(value));
```

A listener that runs later cannot change the event it was given (cancel it, change its message, ...). Use a plain
`connect` for that.

If a listener throws, the others still run; afterwards `fire` rethrows the first exception with the rest attached
as suppressed exceptions.

On a bus that other plugins share, disconnect your own listeners with a `ConnectionGroup`. `Signal.clear()` and
`SignalBus.clear()` remove every listener of a channel or bus, including other plugins' ones.

You can still use GEB directly through the same bus. This keeps GEB useful for
custom `IEvent` events and `@Listen` listeners while SignalsLib handles the
Minecraft-friendly facade:

```java
bus.geb().registerListener(myGebListener);
bus.geb().post(myGebEvent);
```

If your plugin defines its own GEB `@Listen` methods, enable the GEB annotation
processor in that plugin so its event dispatchers are generated.

## Bukkit example

```java
BukkitSignals signals = BukkitSignals.create(plugin);

signals.players().join().connect(event -> {
    event.getPlayer().sendMessage("Hello from Signal!");
});
```

Use the fluent Bukkit API when you need event priority or cancellation behavior:

```java
signals.players().interact()
    .high()
    .ignoreCancelled()
    .connectIf(
        event -> event.getPlayer().hasPermission("signals.debug"),
        event -> event.getPlayer().sendMessage("debug interact")
    );
```

Common events are grouped as `players()`, `blocks()`, `entities()` and `inventories()`.
`players().chat()` is Bukkit's `AsyncPlayerChatEvent`, so its listeners run off the main thread. Hop to the main
thread with `mainThread()` before touching the world (not on Folia, which has no main thread):

```java
signals.players().chat().signal().connectOn(signals.mainThread(), event ->
    event.getPlayer().getWorld().strikeLightningEffect(event.getPlayer().getLocation()));
```

Every other Bukkit event class is still available:

```java
signals.on(PlayerJoinEvent.class).connect(event -> {
    event.getPlayer().sendMessage("Hello from Signal!");
});
```

Or as a one-liner:

```java
BukkitSignals.standaloneSignal(plugin, PlayerJoinEvent.class)
    .connect(event -> event.getPlayer().sendMessage("Hello from Signal!"));
```

If the bundled jar is installed as a server plugin, other plugins can depend on
it and use the shared bus:

```yaml
depend: [SignalsLib]
```

```java
BukkitSignals signals = BukkitSignals.shared();

signals.players().join()
    .connect(event -> event.getPlayer().sendMessage("Hello from shared signals!"));
```

For listener cleanup, keep a group in your plugin and disconnect it on disable:

```java
public final class MyPlugin extends JavaPlugin {
    private final ConnectionGroup connections = ConnectionGroup.create();

    @Override
    public void onEnable() {
        BukkitSignals signals = BukkitSignals.shared();

        signals.blocks().breakBlock()
            .ignoreCancelled()
            .connect(connections, event -> {
                event.getPlayer().sendMessage("Block: " + event.getBlock().getType());
            });
    }

    @Override
    public void onDisable() {
        connections.disconnect();
    }
}
```

## Folia

`signals-folia` is the Bukkit bridge for servers that run regions on separate threads. Install
`SignalsLib-Folia-*.jar` instead of the Bukkit jar (both use the plugin name `SignalsLib`, so install only one).
Plugins depend on it the same way as on the Bukkit jar (`depend: [SignalsLib]`) and add `folia-supported: true`
to their own `plugin.yml`.

Everything in `BukkitSignals` works unchanged. `FoliaSignals` adds listeners that run on the thread they need:

```java
FoliaSignals signals = FoliaSignals.shared();

// Runs on the thread that owns the target player, even if the event came from another region.
signals.connectEntity(
    signals.players().join().signal(),
    event -> event.getPlayer(),
    event -> event.getPlayer().sendMessage("Welcome!")
);

// Runs on the region that owns the block's chunk.
signals.connectRegion(
    signals.blocks().breakBlock().signal(),
    event -> event.getBlock().getLocation(),
    event -> event.getBlock().getRelative(0, 1, 0).setType(Material.AIR)
);

signals.connectGlobal(signals.players().quit().signal(), event -> updateGlobalCounter());
signals.connectAsync(signals.players().quit().signal(), event -> saveToDatabase(event.getPlayer()));
```

Each `connect*` method returns a `Connection` and has a `ConnectionGroup` variant. The listener runs inline when
the current thread already owns the region, entity or global region, and is scheduled otherwise.
`signals.scheduler()` exposes the global, region, entity and async schedulers directly.

Signals and connections are thread-safe, but your own listener code is not: touch blocks, chunks and entities
only on the thread that owns them.

## BungeeCord and Waterfall

Install `SignalsLib-BungeeCord-*.jar` in the proxy's `plugins/` folder and add `depends: [SignalsLib]` to your
`bungee.yml`.

```java
BungeeSignals signals = BungeeSignals.shared();

signals.players().join().connect(event -> {
    event.getPlayer().sendMessage(new TextComponent("Hello from Signal!"));
});

signals.servers().switched().connect(event -> getLogger().info(event.getPlayer().getName() + " switched"));
```

BungeeCord can only register handlers from annotated methods, so SignalsLib bridges a fixed list of events, all at
`NORMAL` priority: pre-login, login, post-login, disconnect, handshake, chat, settings changed, tab complete,
server connect, connected, switch, kick and disconnect, proxy ping, proxy reload and plugin message. Use
`BungeeSignals.bridgedEvents()` to list them. `signals.on(SomeOtherEvent.class)` throws
`IllegalArgumentException`; for other events register a normal BungeeCord listener and fire into
`signals.bus()` yourself.

## Velocity

Install `SignalsLib-Velocity-*.jar` in the proxy's `plugins/` folder and add `signalslib` as a dependency of your
plugin (`@Plugin(dependencies = @Dependency(id = "signalslib"))`).

```java
VelocitySignals signals = VelocitySignals.shared();

signals.players().postLogin()
    .connect(event -> event.getPlayer().sendMessage(Component.text("Hello from Signal!")));

signals.on(ServerPreConnectEvent.class)
    .early()
    .connect(event -> logger.info("Connecting to " + event.getOriginalServer().getServerInfo().getName()));
```

Any Velocity event class works with `signals.on(...)`. Velocity calls handlers from its own thread pools, so
listeners may run on any thread.

## GEB Direct Use

GEB is bundled without relocation, so plugin developers can use
`foo.zaaarf.geb.*` directly from the same jar.

```java
public final class EconomyListener implements IListener {
    @Listen(priority = 10)
    public void onCoinChange(CoinChangeEvent event) {
        handle(event);
    }
}

GebBridge geb = BukkitSignals.sharedBus().geb();
connections.add(geb.loadDispatchers(getClass().getClassLoader()));

geb.listen(connections, new EconomyListener());
```

Keep the connections in a `ConnectionGroup` and disconnect it in `onDisable`, as in the cleanup example above.

Custom GEB events should implement `IEvent` or `IEventCancelable`, and plugins
that define their own `@Listen` methods should enable the GEB annotation
processor at compile time:

```gradle
dependencies {
    compileOnly files("plugins/signals-bukkit-0.2.4-SNAPSHOT-all.jar")
    annotationProcessor "foo.zaaarf.geb:processor:0.4.9"
}
```

GEB only calls a listener once the dispatcher generated for its event type is registered on the bus, and it drops
events without a dispatcher silently. `loadAndRegisterDispatchers` registers the dispatchers the annotation
processor listed in your jar, so call it once with your plugin's class loader, for example in `onEnable`.
`registerDispatcher` and `unregisterDispatcher` do the same for a single dispatcher. A bus keeps one dispatcher per
event type, so registering a second one for the same event type replaces the first.

`loadDispatchers` and `dispatcher` do the same but return a `Connection` that unregisters what they registered
(`loadAndRegisterDispatchers` and `registerDispatcher` cannot be undone that way). Use them on the shared bus:
it outlives your plugin, and would keep your dispatchers, and with them your class loader, alive after a reload.
Connections are only removed again when you disconnect them, so put them in a `ConnectionGroup`.

Sub-buses from GEB 0.5.0 are exposed too. Everything fired on `shared` is forwarded to `local`:

```java
SignalBus shared = BukkitSignals.sharedBus();
SignalBus local = SignalBus.create();

Connection bridge = shared.geb().subBus(local.geb().bus(), 1);
```

Register sub-buses through `geb()` (not on the raw GEB bus): `SignalBus.hasReceivers(key)`, which the BungeeCord,
Velocity and Bukkit bridges use to skip events nobody listens to, counts the sub-buses registered that way. Two
`SignalBus` instances created on the same GEB bus see each other's values for the same reason.

## Build

```bash
./gradlew build
```

```bash
./gradlew build -PspigotApiVersion=26.2-R0.1-SNAPSHOT
```

The platform APIs for the other modules can be changed too:

```bash
./gradlew build -PfoliaApiVersion=1.21.4-R0.1-SNAPSHOT -PbungeeApiVersion=1.21-R0.5-SNAPSHOT -PvelocityApiVersion=3.5.0-SNAPSHOT
```

```bash
./gradlew publishAllPublicationsToLocalBuildRepository
```

Artifacts will be written to each module's `build/libs/` directory.

For plugin distribution, use the bundled `-all.jar` of the platform you run. `./gradlew build` also copies
them, renamed, to `./dist`:

| Platform | Built jar | In `./dist` |
| --- | --- | --- |
| Bukkit/Spigot/Paper | `signals-bukkit/build/libs/signals-bukkit-0.2.4-SNAPSHOT-all.jar` | `SignalsLib-Bukkit-0.2.4-SNAPSHOT.jar` |
| Folia | `signals-folia/build/libs/signals-folia-0.2.4-SNAPSHOT-all.jar` | `SignalsLib-Folia-0.2.4-SNAPSHOT.jar` |
| BungeeCord/Waterfall | `signals-bungeecord/build/libs/signals-bungeecord-0.2.4-SNAPSHOT-all.jar` | `SignalsLib-BungeeCord-0.2.4-SNAPSHOT.jar` |
| Velocity | `signals-velocity/build/libs/signals-velocity-0.2.4-SNAPSHOT-all.jar` | `SignalsLib-Velocity-0.2.4-SNAPSHOT.jar` |

Upload only that jar to the server's or proxy's `plugins/` directory. Each bundled jar
includes `signals-core`, GEB and its plugin descriptor (`plugin.yml`, `bungee.yml` or `velocity-plugin.json`).
None of them relocates `foo.zaaarf.geb`, so plugin developers can use the GEB API directly from the same
jar if they want. The Folia jar also contains `signals-bukkit`.

## Credits

This project bundles and builds on GEB - Generative Event Bus.

- Project: https://zaaarf.foo/projects/geb/
- Source: https://github.com/zaaarf/geb
- Developer ID: `zaaarf`
- Developer email: `me@zaaarf.foo`
- License: MIT
