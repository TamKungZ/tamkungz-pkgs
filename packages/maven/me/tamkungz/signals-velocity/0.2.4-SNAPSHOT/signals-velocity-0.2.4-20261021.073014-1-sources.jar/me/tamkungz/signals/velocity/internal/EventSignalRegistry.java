package me.tamkungz.signals.velocity.internal;

import com.velocitypowered.api.event.EventHandler;
import com.velocitypowered.api.event.PostOrder;
import com.velocitypowered.api.proxy.ProxyServer;
import me.tamkungz.signals.Signal;
import me.tamkungz.signals.SignalBus;
import me.tamkungz.signals.SignalKey;

import java.util.AbstractMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Registers one Velocity handler per event type and post order, and caches the {@link Signal} each of them feeds.
 * <p>
 * Internal: use {@code VelocitySignals} instead.
 */
public final class EventSignalRegistry {
    private final Object plugin;
    private final ProxyServer proxy;
    private final SignalBus bus;
    private final Map<Map.Entry<Class<?>, PostOrder>, Signal<?>> channels = new ConcurrentHashMap<>();

    /**
     * Creates a registry that registers Velocity handlers for a plugin and fires onto a bus.
     *
     * @param plugin plugin instance that owns the Velocity handlers
     * @param proxy the proxy whose event manager the handlers are registered on
     * @param bus bus the signals live on
     */
    public EventSignalRegistry(Object plugin, ProxyServer proxy, SignalBus bus) {
        this.plugin = Objects.requireNonNull(plugin, "plugin");
        this.proxy = Objects.requireNonNull(proxy, "proxy");
        this.bus = Objects.requireNonNull(bus, "bus");
    }

    /**
     * Returns the signal for an event type with the given post order, registering the Velocity handler on
     * first use.
     *
     * @param eventType Velocity event type
     * @param order order in which the Velocity handler runs
     * @param <T> event type
     * @return the signal for that combination
     */
    public <T> Signal<T> signal(Class<T> eventType, PostOrder order) {
        Objects.requireNonNull(eventType, "eventType");
        Objects.requireNonNull(order, "order");
        @SuppressWarnings("unchecked")
        Signal<T> signal = (Signal<T>) channels.computeIfAbsent(
                new AbstractMap.SimpleImmutableEntry<>(eventType, order),
                ignored -> register(eventType, order)
        );
        return signal;
    }

    // Velocity 3.3 added a short-priority overload and deprecated this PostOrder one, but PostOrder is still the
    // documented ordering in Velocity 3.x and 4.x, so it stays.
    @SuppressWarnings("deprecation")
    private <T> Signal<T> register(Class<T> eventType, PostOrder order) {
        SignalKey<T> signalKey = order == PostOrder.NORMAL
                ? SignalKey.of(eventType)
                : SignalKey.named(eventType, "velocity:" + order.name());
        Signal<T> signal = bus.signal(signalKey);
        // hasReceivers also counts the sub-buses of the bus; listenerCount() alone would drop events whose only
        // listeners live on a sub-bus.
        EventHandler<T> handler = event -> {
            if (signal.hasReceivers()) {
                signal.fire(event);
            }
        };
        proxy.getEventManager().register(plugin, eventType, order, handler);
        return signal;
    }
}
