package me.tamkungz.signals.velocity;

import com.google.inject.Inject;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.proxy.ProxyShutdownEvent;
import com.velocitypowered.api.proxy.ProxyServer;
import me.tamkungz.signals.SignalBus;
import me.tamkungz.signals.connection.Connection;
import me.tamkungz.signals.connection.ConnectionGroup;
import org.slf4j.Logger;

/**
 * Velocity plugin entrypoint for proxies that want to load SignalsLib as a shared library.
 * <p>
 * The plugin id is {@code signalslib}; other plugins list it as a dependency and use
 * {@link VelocitySignals#shared()}. Its {@code velocity-plugin.json} is written by hand instead of being
 * generated from {@code @Plugin}, so the version always follows the build.
 */
public final class SignalsVelocityPlugin {
    private static volatile SignalsVelocityPlugin instance;

    private final Logger logger;
    private final VelocitySignals signals;
    private final ConnectionGroup connections = ConnectionGroup.create();

    /**
     * Called by Velocity.
     *
     * @param server the proxy
     * @param logger logger of this plugin
     */
    @Inject
    public SignalsVelocityPlugin(ProxyServer server, Logger logger) {
        this.logger = logger;
        this.signals = VelocitySignals.create(this, server);
        instance = this;
    }

    /**
     * Returns the loaded SignalsLib plugin.
     *
     * @return the plugin instance
     * @throws IllegalStateException if SignalsLib is not loaded
     */
    public static SignalsVelocityPlugin getInstance() {
        SignalsVelocityPlugin plugin = instance;
        if (plugin == null) {
            throw new IllegalStateException("SignalsLib is not loaded; add it to the proxy's plugins folder "
                    + "and list it as a dependency");
        }
        return plugin;
    }

    /**
     * Cleans up when the proxy shuts down.
     *
     * @param event shutdown event
     */
    @Subscribe
    public void onProxyShutdown(ProxyShutdownEvent event) {
        connections.disconnect();
        signals.bus().clear();
        instance = null;
        logger.info("SignalsLib disabled");
    }

    public VelocitySignals signals() {
        return signals;
    }

    public SignalBus bus() {
        return signals.bus();
    }

    public ConnectionGroup connections() {
        return connections;
    }

    public <T extends Connection> T track(T connection) {
        return connections.add(connection);
    }
}
