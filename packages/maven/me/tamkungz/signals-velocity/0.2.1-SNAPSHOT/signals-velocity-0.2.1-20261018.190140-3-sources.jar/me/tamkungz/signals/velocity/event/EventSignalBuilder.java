package me.tamkungz.signals.velocity.event;

import com.velocitypowered.api.event.PostOrder;
import me.tamkungz.signals.Signal;
import me.tamkungz.signals.connection.Connection;
import me.tamkungz.signals.connection.ConnectionGroup;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Predicate;

/**
 * Fluent options (post order) for listening to one Velocity event type.
 * <p>
 * Pick the order, then either call {@link #signal()} or connect a listener directly.
 *
 * @param <T> Velocity event type
 */
public final class EventSignalBuilder<T> {
    private final EventSignalSource source;
    private final Class<T> eventType;
    private PostOrder order = PostOrder.NORMAL;

    /**
     * Creates a builder; prefer {@link EventSignalSource#on(Class)}.
     *
     * @param source where the signal comes from
     * @param eventType Velocity event type
     */
    public EventSignalBuilder(EventSignalSource source, Class<T> eventType) {
        this.source = Objects.requireNonNull(source, "source");
        this.eventType = Objects.requireNonNull(eventType, "eventType");
    }

    public EventSignalBuilder<T> order(PostOrder order) {
        this.order = Objects.requireNonNull(order, "order");
        return this;
    }

    public EventSignalBuilder<T> first() {
        return order(PostOrder.FIRST);
    }

    public EventSignalBuilder<T> early() {
        return order(PostOrder.EARLY);
    }

    public EventSignalBuilder<T> normal() {
        return order(PostOrder.NORMAL);
    }

    public EventSignalBuilder<T> late() {
        return order(PostOrder.LATE);
    }

    public EventSignalBuilder<T> last() {
        return order(PostOrder.LAST);
    }

    public Signal<T> signal() {
        return source.signal(eventType, order);
    }

    public Connection connect(Consumer<T> listener) {
        return signal().connect(listener);
    }

    public Connection connect(ConnectionGroup group, Consumer<T> listener) {
        return signal().connect(group, listener);
    }

    public Connection connectIf(Predicate<T> predicate, Consumer<T> listener) {
        return signal().connectIf(predicate, listener);
    }

    public Connection connectIf(ConnectionGroup group, Predicate<T> predicate, Consumer<T> listener) {
        return signal().connectIf(group, predicate, listener);
    }

    public Connection once(Consumer<T> listener) {
        return signal().once(listener);
    }

    public Connection once(ConnectionGroup group, Consumer<T> listener) {
        return signal().once(group, listener);
    }
}
