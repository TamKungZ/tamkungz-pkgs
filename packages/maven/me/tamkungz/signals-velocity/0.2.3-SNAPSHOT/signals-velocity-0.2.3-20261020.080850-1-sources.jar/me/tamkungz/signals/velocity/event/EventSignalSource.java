package me.tamkungz.signals.velocity.event;

import com.velocitypowered.api.event.PostOrder;
import me.tamkungz.signals.Signal;

/**
 * Supplies the {@link Signal} that carries a Velocity event for a given post order.
 * <p>
 * The fluent {@link EventSignalBuilder} and the per-domain accessors depend on this interface only, which keeps
 * them free of {@code VelocitySignals} itself.
 */
public interface EventSignalSource {
    /**
     * Returns the signal for an event type with the given post order.
     *
     * @param eventType Velocity event type
     * @param order order in which the underlying Velocity handler runs relative to other handlers
     * @param <T> event type
     * @return the signal for that combination
     */
    <T> Signal<T> signal(Class<T> eventType, PostOrder order);

    /**
     * Returns the signal for an event type at {@link PostOrder#NORMAL}.
     *
     * @param eventType Velocity event type
     * @param <T> event type
     * @return the default signal for the event type
     */
    default <T> Signal<T> signal(Class<T> eventType) {
        return signal(eventType, PostOrder.NORMAL);
    }

    /**
     * Starts a fluent configuration for an event type.
     *
     * @param eventType Velocity event type
     * @param <T> event type
     * @return a builder for the post order option
     */
    default <T> EventSignalBuilder<T> on(Class<T> eventType) {
        return new EventSignalBuilder<>(this, eventType);
    }
}
