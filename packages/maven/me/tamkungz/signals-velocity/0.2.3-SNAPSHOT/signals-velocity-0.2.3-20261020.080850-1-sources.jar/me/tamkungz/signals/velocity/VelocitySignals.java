package me.tamkungz.signals.velocity;

import com.velocitypowered.api.event.PostOrder;
import com.velocitypowered.api.proxy.ProxyServer;
import me.tamkungz.signals.Signal;
import me.tamkungz.signals.SignalBus;
import me.tamkungz.signals.velocity.event.EventSignalSource;
import me.tamkungz.signals.velocity.event.PlayerSignals;
import me.tamkungz.signals.velocity.event.ProxySignals;
import me.tamkungz.signals.velocity.event.ServerSignals;
import me.tamkungz.signals.velocity.internal.EventSignalRegistry;

import java.util.Objects;

/**
 * Small bridge from Velocity events to GEB-backed signals.
 * <p>
 * Common events are grouped by domain: {@link #players()}, {@link #servers()} and {@link #proxy()}. Any other
 * Velocity event type is available through {@link #on(Class)}.
 * <p>
 * Velocity runs handlers on its own thread pools, so listeners connected here may be called from any thread.
 */
public final class VelocitySignals implements EventSignalSource {
    private final SignalBus bus;
    private final EventSignalRegistry registry;
    private final PlayerSignals players;
    private final ServerSignals servers;
    private final ProxySignals proxy;

    private VelocitySignals(Object plugin, ProxyServer server, SignalBus bus) {
        Objects.requireNonNull(plugin, "plugin");
        Objects.requireNonNull(server, "server");
        this.bus = Objects.requireNonNull(bus, "bus");
        this.registry = new EventSignalRegistry(plugin, server, bus);
        this.players = new PlayerSignals(this);
        this.servers = new ServerSignals(this);
        this.proxy = new ProxySignals(this);
    }

    /**
     * Creates a bridge with its own signal bus.
     * <p>
     * Velocity handlers are registered lazily, the first time a signal is requested, so the plugin must be
     * loaded by then (for example from {@code ProxyInitializeEvent} on).
     *
     * @param plugin plugin instance that owns the Velocity handlers
     * @param server the proxy
     * @return a new bridge
     */
    public static VelocitySignals create(Object plugin, ProxyServer server) {
        return new VelocitySignals(plugin, server, SignalBus.create());
    }

    /**
     * Creates a bridge on an existing signal bus.
     *
     * @param plugin plugin instance that owns the Velocity handlers
     * @param server the proxy
     * @param bus bus the signals live on
     * @return a new bridge
     */
    public static VelocitySignals create(Object plugin, ProxyServer server, SignalBus bus) {
        return new VelocitySignals(plugin, server, bus);
    }

    /**
     * Returns the bridge shared by every plugin through the installed SignalsLib plugin.
     *
     * @return the shared bridge
     */
    public static VelocitySignals shared() {
        return SignalsVelocityPlugin.getInstance().signals();
    }

    /**
     * Returns the signal bus shared by every plugin through the installed SignalsLib plugin.
     *
     * @return the shared bus
     */
    public static SignalBus sharedBus() {
        return SignalsVelocityPlugin.getInstance().bus();
    }

    /**
     * Creates a private bridge for a single event type and returns its signal.
     *
     * @param plugin plugin instance that owns the Velocity handler
     * @param server the proxy
     * @param eventType Velocity event type
     * @param order order in which the Velocity handler runs
     * @param <T> event type
     * @return the signal for that event type
     */
    public static <T> Signal<T> standaloneSignal(
            Object plugin,
            ProxyServer server,
            Class<T> eventType,
            PostOrder order
    ) {
        return create(plugin, server).signal(eventType, order);
    }

    /**
     * Creates a private bridge for a single event type at {@link PostOrder#NORMAL} and returns its signal.
     *
     * @param plugin plugin instance that owns the Velocity handler
     * @param server the proxy
     * @param eventType Velocity event type
     * @param <T> event type
     * @return the signal for that event type
     */
    public static <T> Signal<T> standaloneSignal(Object plugin, ProxyServer server, Class<T> eventType) {
        return standaloneSignal(plugin, server, eventType, PostOrder.NORMAL);
    }

    /**
     * Returns the signal bus behind this bridge.
     *
     * @return the signal bus
     */
    public SignalBus bus() {
        return bus;
    }

    @Override
    public <T> Signal<T> signal(Class<T> eventType, PostOrder order) {
        return registry.signal(eventType, order);
    }

    /**
     * Returns shortcuts for player events.
     *
     * @return player signals
     */
    public PlayerSignals players() {
        return players;
    }

    /**
     * Returns shortcuts for backend server events.
     *
     * @return server signals
     */
    public ServerSignals servers() {
        return servers;
    }

    /**
     * Returns shortcuts for proxy events.
     *
     * @return proxy signals
     */
    public ProxySignals proxy() {
        return proxy;
    }
}
