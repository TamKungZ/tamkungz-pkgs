/**
 * Velocity entry points: {@link me.tamkungz.signals.velocity.VelocitySignals} and the
 * {@link me.tamkungz.signals.velocity.SignalsVelocityPlugin} that shares one bridge between plugins.
 */
package me.tamkungz.signals.velocity;
