package me.tamkungz.signals.velocity.event;

import com.velocitypowered.api.event.PostOrder;
import me.tamkungz.signals.Signal;
import me.tamkungz.signals.connection.Connection;
import me.tamkungz.signals.connection.ConnectionGroup;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Predicate;

/**
 * Fluent options (post order) for listening to one Velocity event type.
 * <p>
 * Pick the order, then either call {@link #signal()} or connect a listener directly.
 *
 * @param <T> Velocity event type
 */
public final class EventSignalBuilder<T> {
    private final EventSignalSource source;
    private final Class<T> eventType;
    private PostOrder order = PostOrder.NORMAL;

    /**
     * Creates a builder; prefer {@link EventSignalSource#on(Class)}.
     *
     * @param source where the signal comes from
     * @param eventType Velocity event type
     */
    public EventSignalBuilder(EventSignalSource source, Class<T> eventType) {
        this.source = Objects.requireNonNull(source, "source");
        this.eventType = Objects.requireNonNull(eventType, "eventType");
    }

    /**
     * Sets the order the underlying Velocity handler runs in; the default is {@link PostOrder#NORMAL}.
     *
     * @param order Velocity post order
     * @return this builder
     */
    public EventSignalBuilder<T> order(PostOrder order) {
        this.order = Objects.requireNonNull(order, "order");
        return this;
    }

    /**
     * Same as {@code order(PostOrder.FIRST)}.
     *
     * @return this builder
     */
    public EventSignalBuilder<T> first() {
        return order(PostOrder.FIRST);
    }

    /**
     * Same as {@code order(PostOrder.EARLY)}.
     *
     * @return this builder
     */
    public EventSignalBuilder<T> early() {
        return order(PostOrder.EARLY);
    }

    /**
     * Same as {@code order(PostOrder.NORMAL)}.
     *
     * @return this builder
     */
    public EventSignalBuilder<T> normal() {
        return order(PostOrder.NORMAL);
    }

    /**
     * Same as {@code order(PostOrder.LATE)}.
     *
     * @return this builder
     */
    public EventSignalBuilder<T> late() {
        return order(PostOrder.LATE);
    }

    /**
     * Same as {@code order(PostOrder.LAST)}.
     *
     * @return this builder
     */
    public EventSignalBuilder<T> last() {
        return order(PostOrder.LAST);
    }

    /**
     * Returns the signal for the chosen order, registering the Velocity handler on first use.
     *
     * @return the signal for this event type and order
     */
    public Signal<T> signal() {
        return source.signal(eventType, order);
    }

    /**
     * Connects a listener to the signal for the chosen order.
     *
     * @param listener listener to call for every event
     * @return the connection for this listener
     */
    public Connection connect(Consumer<T> listener) {
        return signal().connect(listener);
    }

    /**
     * Connects a listener and tracks it in a group.
     *
     * @param group group that will disconnect the listener
     * @param listener listener to call for every event
     * @return the connection for this listener
     */
    public Connection connect(ConnectionGroup group, Consumer<T> listener) {
        return signal().connect(group, listener);
    }

    /**
     * Connects a listener that only receives the events a predicate accepts.
     *
     * @param predicate decides which events reach the listener
     * @param listener listener to call for accepted events
     * @return the connection for this listener
     */
    public Connection connectIf(Predicate<T> predicate, Consumer<T> listener) {
        return signal().connectIf(predicate, listener);
    }

    /**
     * Connects a filtered listener and tracks it in a group.
     *
     * @param group group that will disconnect the listener
     * @param predicate decides which events reach the listener
     * @param listener listener to call for accepted events
     * @return the connection for this listener
     */
    public Connection connectIf(ConnectionGroup group, Predicate<T> predicate, Consumer<T> listener) {
        return signal().connectIf(group, predicate, listener);
    }

    /**
     * Connects a listener that is disconnected after its first event.
     *
     * @param listener listener to call at most once
     * @return the connection for this listener
     */
    public Connection once(Consumer<T> listener) {
        return signal().once(listener);
    }

    /**
     * Connects a one-shot listener and tracks it in a group.
     *
     * @param group group that will disconnect the listener
     * @param listener listener to call at most once
     * @return the connection for this listener
     */
    public Connection once(ConnectionGroup group, Consumer<T> listener) {
        return signal().once(group, listener);
    }
}
