/**
 * Implementation details of the Velocity bridge. Not part of the public API and may change without notice.
 */
package me.tamkungz.signals.velocity.internal;
