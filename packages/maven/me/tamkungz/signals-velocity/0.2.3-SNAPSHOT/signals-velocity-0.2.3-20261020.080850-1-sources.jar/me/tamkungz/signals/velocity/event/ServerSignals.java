package me.tamkungz.signals.velocity.event;

import com.velocitypowered.api.event.player.KickedFromServerEvent;
import com.velocitypowered.api.event.player.ServerConnectedEvent;
import com.velocitypowered.api.event.player.ServerPostConnectEvent;
import com.velocitypowered.api.event.player.ServerPreConnectEvent;

import java.util.Objects;

/**
 * Shortcuts for common Velocity backend server events, reached with {@code VelocitySignals#servers()}.
 * <p>
 * Each method is the same as {@link EventSignalSource#on(Class)} for the named event class;
 * anything not listed here is still available through that method.
 */
public final class ServerSignals {
    private final EventSignalSource source;

    /**
     * Creates the shortcuts; prefer {@code VelocitySignals#servers()}.
     *
     * @param source where the signals come from
     */
    public ServerSignals(EventSignalSource source) {
        this.source = Objects.requireNonNull(source, "source");
    }

    /**
     * Listens to {@link ServerPreConnectEvent}.
     *
     * @return a builder for the post order option
     */
    public EventSignalBuilder<ServerPreConnectEvent> preConnect() {
        return source.on(ServerPreConnectEvent.class);
    }

    /**
     * Listens to {@link ServerConnectedEvent}.
     *
     * @return a builder for the post order option
     */
    public EventSignalBuilder<ServerConnectedEvent> connected() {
        return source.on(ServerConnectedEvent.class);
    }

    /**
     * Listens to {@link ServerPostConnectEvent}.
     *
     * @return a builder for the post order option
     */
    public EventSignalBuilder<ServerPostConnectEvent> postConnect() {
        return source.on(ServerPostConnectEvent.class);
    }

    /**
     * Listens to {@link KickedFromServerEvent}.
     *
     * @return a builder for the post order option
     */
    public EventSignalBuilder<KickedFromServerEvent> kicked() {
        return source.on(KickedFromServerEvent.class);
    }
}
