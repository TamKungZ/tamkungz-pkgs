package me.tamkungz.signals.velocity.event;

import com.velocitypowered.api.event.command.CommandExecuteEvent;
import com.velocitypowered.api.event.connection.DisconnectEvent;
import com.velocitypowered.api.event.connection.LoginEvent;
import com.velocitypowered.api.event.connection.PostLoginEvent;
import com.velocitypowered.api.event.connection.PreLoginEvent;
import com.velocitypowered.api.event.player.PlayerChatEvent;
import com.velocitypowered.api.event.player.PlayerChooseInitialServerEvent;
import com.velocitypowered.api.event.player.PlayerSettingsChangedEvent;

import java.util.Objects;

/**
 * Shortcuts for common Velocity player events, reached with {@code VelocitySignals#players()}.
 * <p>
 * Each method is the same as {@link EventSignalSource#on(Class)} for the named event class;
 * anything not listed here is still available through that method.
 */
public final class PlayerSignals {
    private final EventSignalSource source;

    /**
     * Creates the shortcuts; prefer {@code VelocitySignals#players()}.
     *
     * @param source where the signals come from
     */
    public PlayerSignals(EventSignalSource source) {
        this.source = Objects.requireNonNull(source, "source");
    }

    /**
     * Listens to {@link PreLoginEvent}.
     *
     * @return a builder for the post order option
     */
    public EventSignalBuilder<PreLoginEvent> preLogin() {
        return source.on(PreLoginEvent.class);
    }

    /**
     * Listens to {@link LoginEvent}.
     *
     * @return a builder for the post order option
     */
    public EventSignalBuilder<LoginEvent> login() {
        return source.on(LoginEvent.class);
    }

    /**
     * Listens to {@link PostLoginEvent}.
     *
     * @return a builder for the post order option
     */
    public EventSignalBuilder<PostLoginEvent> postLogin() {
        return source.on(PostLoginEvent.class);
    }

    /**
     * Listens to {@link DisconnectEvent}.
     *
     * @return a builder for the post order option
     */
    public EventSignalBuilder<DisconnectEvent> disconnect() {
        return source.on(DisconnectEvent.class);
    }

    /**
     * Listens to {@link PlayerChatEvent}.
     * <p>
     * For clients on 1.19.1 and newer that sign their chat, Velocity cannot deny or change the message.
     *
     * @return a builder for the post order option
     */
    public EventSignalBuilder<PlayerChatEvent> chat() {
        return source.on(PlayerChatEvent.class);
    }

    /**
     * Listens to {@link CommandExecuteEvent}.
     *
     * @return a builder for the post order option
     */
    public EventSignalBuilder<CommandExecuteEvent> command() {
        return source.on(CommandExecuteEvent.class);
    }

    /**
     * Listens to {@link PlayerSettingsChangedEvent}.
     *
     * @return a builder for the post order option
     */
    public EventSignalBuilder<PlayerSettingsChangedEvent> settingsChanged() {
        return source.on(PlayerSettingsChangedEvent.class);
    }

    /**
     * Listens to {@link PlayerChooseInitialServerEvent}.
     *
     * @return a builder for the post order option
     */
    public EventSignalBuilder<PlayerChooseInitialServerEvent> chooseInitialServer() {
        return source.on(PlayerChooseInitialServerEvent.class);
    }
}
