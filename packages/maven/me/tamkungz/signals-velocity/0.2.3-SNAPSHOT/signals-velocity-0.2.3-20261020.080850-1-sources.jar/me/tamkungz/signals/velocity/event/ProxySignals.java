package me.tamkungz.signals.velocity.event;

import com.velocitypowered.api.event.connection.PluginMessageEvent;
import com.velocitypowered.api.event.proxy.ProxyInitializeEvent;
import com.velocitypowered.api.event.proxy.ProxyPingEvent;
import com.velocitypowered.api.event.proxy.ProxyReloadEvent;
import com.velocitypowered.api.event.proxy.ProxyShutdownEvent;

import java.util.Objects;

/**
 * Shortcuts for common Velocity proxy events, reached with {@code VelocitySignals#proxy()}.
 * <p>
 * Each method is the same as {@link EventSignalSource#on(Class)} for the named event class;
 * anything not listed here is still available through that method.
 */
public final class ProxySignals {
    private final EventSignalSource source;

    /**
     * Creates the shortcuts; prefer {@code VelocitySignals#proxy()}.
     *
     * @param source where the signals come from
     */
    public ProxySignals(EventSignalSource source) {
        this.source = Objects.requireNonNull(source, "source");
    }

    /**
     * Listens to {@link ProxyInitializeEvent}.
     * <p>
     * Velocity does not call handlers added while the event is already being fired, so request this signal
     * (and connect to it) in your plugin's constructor, not from inside another {@code ProxyInitializeEvent}
     * handler.
     *
     * @return a builder for the post order option
     */
    public EventSignalBuilder<ProxyInitializeEvent> initialize() {
        return source.on(ProxyInitializeEvent.class);
    }

    /**
     * Listens to {@link ProxyShutdownEvent}.
     *
     * @return a builder for the post order option
     */
    public EventSignalBuilder<ProxyShutdownEvent> shutdown() {
        return source.on(ProxyShutdownEvent.class);
    }

    /**
     * Listens to {@link ProxyReloadEvent}.
     *
     * @return a builder for the post order option
     */
    public EventSignalBuilder<ProxyReloadEvent> reload() {
        return source.on(ProxyReloadEvent.class);
    }

    /**
     * Listens to {@link ProxyPingEvent}.
     *
     * @return a builder for the post order option
     */
    public EventSignalBuilder<ProxyPingEvent> ping() {
        return source.on(ProxyPingEvent.class);
    }

    /**
     * Listens to {@link PluginMessageEvent}.
     *
     * @return a builder for the post order option
     */
    public EventSignalBuilder<PluginMessageEvent> pluginMessage() {
        return source.on(PluginMessageEvent.class);
    }
}
