/**
 * Fluent Velocity event options and per-domain shortcuts (players, servers, proxy).
 */
package me.tamkungz.signals.velocity.event;
